<?php 
require_once('../config/config.php');
die_login();
$conn = conn();
die_conn($conn);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Administrator</title>
<link type="image/x-icon" rel="icon" href="../images/favicon.ico">

<!-- CSS -->
<link type="text/css" href="../config/css/style.css" rel="stylesheet">
<link type="text/css" href="../config/css/menu.css" rel="stylesheet">
<link type="text/css" href="../plugin/css/zebra/default.css" rel="stylesheet">
<link type="text/css" href="../plugin/window/themes/default.css" rel="stylesheet">
<link type="text/css" href="../plugin/window/themes/mac_os_x.css" rel="stylesheet">

<!-- JS -->
<script type="text/javascript" src="../plugin/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="../plugin/js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="../config/js/menu.js"></script>
<script type="text/javascript" src="../plugin/js/jquery.inputmask.custom.js"></script>
<script type="text/javascript" src="../plugin/js/keymaster.js"></script>
<script type="text/javascript" src="../plugin/js/zebra_datepicker.js"></script>
<script type="text/javascript" src="../plugin/js/jquery.ajaxfileupload.js"></script>
<script type="text/javascript" src="../plugin/window/javascripts/prototype.js"></script>
<script type="text/javascript" src="../plugin/window/javascripts/window.js"></script>
<script type="text/javascript" src="../config/js/main.js"></script>
<style type="text/css">
html { height:100%; }
body {
	position:relative;
	background:#990000;
	margin:0;
}
body { height:100%; }
</style>
</head>
<body>
<div id="wrapper">
	<div id="header">
		<span class="pkb">
			<span class="big">P</span>engelola <span class="big">K</span>awasan <span class="big">B</span>intaro
			<span class="desc">Program Pembayaran <span class="air">Air</span> dan <span class="ipl">IPL</span></span>
		</span>
	</div>
	<div id="menu"><?php include('menu.php'); ?></div>
	<div id="content">
		<div class="clear"></div>
		<?php 
		$cmd = (isset($_REQUEST['cmd'])) ? strip_tags($_REQUEST['cmd']) : '';
		switch (trim(base64_decode($cmd)))
		{
			# Master
			case 'parameter' 			: die_mod('M1'); include('master/parameter/parameter_setup.php');break;
			case 'sektor'				: die_mod('M2'); include('master/sektor/sektor_setup.php');break;
			case 'cluster'				: die_mod('M3'); include('master/cluster/cluster_setup.php');break;
			case 'bank'					: die_mod('M4'); include('master/bank/bank_setup.php');break;
				
			## AIR, IPL, DEPOSIT
			case 'diskon'				: die_mod('M5'); include('master/diskon/diskon_setup.php');break; 
			case 'pompa'				: die_mod('M6'); include('master/pompa/pompa_setup.php');break; 
			
			case 'sk_air'				: die_mod('M7'); include('master/sk_air/sk_air_setup.php');break;
			case 'kategori_air'			: die_mod('M8'); include('master/kategori_air/kategori_air_setup.php');break;
			case 'tarif_air'			: die_mod('M9'); include('master/tarif_air/tarif_air_setup.php');break;
			
			case 'sk_ipl'				: die_mod('M10'); include('master/sk_ipl/sk_ipl_setup.php');break;
			case 'kategori_ipl'			: die_mod('M11'); include('master/kategori_ipl/kategori_ipl_setup.php');break;
			case 'tarif_ipl'			: die_mod('M12'); include('master/tarif_ipl/tarif_ipl_setup.php');break;
			
			case 'pelanggan'			: die_mod('M13'); include('master/pelanggan/pelanggan_setup.php');break; 
			case 'pelanggan_fa'			: die_mod('M15'); include('master/pelanggan_fa/pelanggan_fa_setup.php');break; 
			case 'pelanggan_baru'		: die_mod('M14'); include('master/pelanggan_baru/pelanggan_baru_setup.php');break; 
			
			# Proses Tagihan
				case 'periode_bangun'	: die_mod('T1'); include('periode/periode_bangun/periode_bangun_setup.php');break;
				case 'periode_renovasi'	: die_mod('T2'); include('periode/periode_renovasi/periode_renovasi_setup.php');break;
				
				case 'copy_periode'		: die_mod('T3'); include('periode/copy_periode/copy_periode_setup.php');break;
				case 'edit_sm'			: die_mod('T8'); include('periode/edit_sm/edit_sm_setup.php');break;
				case 'export_sm'		: die_mod('T4'); include('periode/export_sm/export_sm_setup.php');break;
				case 'import_sm'		: die_mod('T5'); include('periode/import_sm/import_sm_setup.php');break; 
				
				case 'hitung_denda'		: die_mod('T6'); include('periode/hitung_denda/hitung_denda_setup.php');break;
				case 'proses_tagihan'	: die_mod('T7'); include('periode/proses_tagihan/proses_tagihan_setup.php');break;
				
			# Bank
				case 'export_bank'		: die_mod('B1'); include('bank/export/export_setup.php');break;
				case 'import_bank'		: die_mod('B2'); include('bank/import/import_setup.php');break;
			
			# Pembayaran
				case 'ai_pembayaran'		: die_mod('PA1'); include('pembayaran/air_ipl/pembayaran_setup.php');break;
				case 'ai_pelanggan_baru'	: die_mod('PA2'); include('pembayaran/air_ipl/pelanggan_baru/pelanggan_baru_setup.php');break;
				
				case 'dp_pembayaran'		: die_mod('PD1'); include('pembayaran/deposit/pembayaran_setup.php');break;
				case 'll_pembayaran'		: die_mod('PL1'); include('pembayaran/lain_lain/pembayaran_setup.php');break;
				
			# Laporan
				## Air IPL
					### Rencana
					case 'ai_rencana_rincian'		: die_mod('LA1'); include('laporan/air_ipl/rencana_rincian/rencana_rincian_setup.php');break; 
					case 'ai_rencana_rekap'			: die_mod('LA2'); include('laporan/air_ipl/rencana_rekap/rencana_rekap_setup.php');break; 
				
					### Penerimaan
					case 'ai_penerimaan_rincian'	: die_mod('LA3'); include('laporan/air_ipl/penerimaan_rincian/penerimaan_rincian_setup.php');break; 
					case 'ai_penerimaan_rekap'		: die_mod('LA4'); include('laporan/air_ipl/penerimaan_rekap/penerimaan_rekap_setup.php');break;
					
					### Piutang
					case 'ai_piutang_rincian'		: die_mod('LA5'); include('laporan/air_ipl/piutang_rincian/piutang_rincian_setup.php');break; 
					case 'ai_piutang_rekap'			: die_mod('LA6'); include('laporan/air_ipl/piutang_rekap/piutang_rekap_setup.php');break;
					case 'ai_piutang_umur'			: die_mod('LA7'); include('laporan/air_ipl/piutang_umur/piutang_umur_setup.php');break;
				
					case 'ai_pemutusan'				: die_mod('LA8'); include('laporan/air_ipl/pemutusan/pemutusan_setup.php');break;
					case 'ai_pemakaian_air'			: die_mod('LA9'); include('laporan/air_ipl/pemakaian_air/pemakaian_air_setup.php');break;
					
				## Deposit
					### Rencana
					case 'dp_rencana_rincian'		: die_mod('LD1'); include('laporan/deposit/rencana_rincian/rencana_rincian_setup.php');break; 
					case 'dp_rencana_rekap'			: die_mod('LD2'); include('laporan/deposit/rencana_rekap/rencana_rekap_setup.php');break; 
				
					### Penerimaan
					case 'dp_penerimaan_rincian'	: die_mod('LD3'); include('laporan/deposit/penerimaan_rincian/penerimaan_rincian_setup.php');break; 
					case 'dp_penerimaan_rekap'		: die_mod('LD4'); include('laporan/deposit/penerimaan_rekap/penerimaan_rekap_setup.php');break; 
				
					### Piutang
					case 'dp_piutang_rincian'		: die_mod('LD5'); include('laporan/deposit/piutang_rincian/piutang_rincian_setup.php');break; 
					case 'dp_piutang_rekap'			: die_mod('LD6'); include('laporan/deposit/piutang_rekap/piutang_rekap_setup.php');break;
					case 'dp_piutang_umur'			: die_mod('LD7'); include('laporan/deposit/piutang_umur/piutang_umur_setup.php');break;
				
				## Deposit
					### Rencana
					case 'll_rencana_rincian'		: die_mod('LL1'); include('laporan/lain_lain/rencana_rincian/rencana_rincian_setup.php');break; 
					case 'll_rencana_rekap'			: die_mod('LL2'); include('laporan/lain_lain/rencana_rekap/rencana_rekap_setup.php');break; 
				
					### Penerimaan
					case 'll_penerimaan_rincian'	: die_mod('LL3'); include('laporan/lain_lain/penerimaan_rincian/penerimaan_rincian_setup.php');break; 
					case 'll_penerimaan_rekap'		: die_mod('LL4'); include('laporan/lain_lain/penerimaan_rekap/penerimaan_rekap_setup.php');break; 
				
					### Piutang
					case 'll_piutang_rincian'		: die_mod('LL5'); include('laporan/lain_lain/piutang_rincian/piutang_rincian_setup.php');break; 
					case 'll_piutang_rekap'			: die_mod('LL6'); include('laporan/lain_lain/piutang_rekap/piutang_rekap_setup.php');break;
					case 'll_piutang_umur'			: die_mod('Ll7'); include('laporan/lain_lain/piutang_umur/piutang_umur_setup.php');break;
					
				## Pelanggan
					case 'pelanggan_rincian'		: die_mod('LP1'); include('laporan/pelanggan/pelanggan_rincian/pelanggan_rincian_setup.php');break;
					case 'pelanggan_rekap'			: die_mod('LP2'); include('laporan/pelanggan/pelanggan_rekap/pelanggan_rekap_setup.php');break;
					case 'pelanggan_daftar'			: die_mod('LP3'); include('laporan/pelanggan/pelanggan_daftar/pelanggan_daftar_setup.php');break;
				
				case 'bd_rincian'					: die_mod('LB1'); include('laporan/bd/rincian/rincian_setup.php');break;
				case 'bd_rekap'						: die_mod('LB2'); include('laporan/bd/rekap/rekap_setup.php');break;
				case 'daftar_faktur_pajak'			: die_mod('LB3'); include('laporan/daftar_faktur_pajak/daftar_faktur_pajak_setup.php');break;
				
			# Utilitas
				## Invoice
				case 'ai_invoice'					: die_mod('U1'); include('invoice/air_ipl/invoice_setup.php');break; 
				case 'dp_invoice'					: die_mod('U2'); include('invoice/deposit/invoice_setup.php');break; 
				case 'll_invoice'					: die_mod('U10'); include('invoice/lain_lain/invoice_setup.php');break; 
				
				## Posting 
				case 'posting_pembayaran'			: die_mod('U3'); include('pembayaran/posting/posting_setup.php');break; 
				case 'proses_bd'					: die_mod('U4'); include('bd/bd_setup.php');break; 
					
				## Faktur Pajak
				case 'fp_penomoran'					: die_mod('U5'); include('faktur_pajak/penomoran/penomoran_setup.php');break; 
				case 'fp_cetak'						: die_mod('U6'); include('faktur_pajak/cetak/cetak_setup.php');break; 
				case 'fp_posting'					: die_mod('U7'); include('faktur_pajak/posting/posting_setup.php');break; 
				
				case 'user_management'				: die_mod('U8'); include('user/management/management_setup.php');break; 
				case 'user_log'						: die_mod('U9'); include('user/log/log_setup.php');break;
				
			default: include('dashboard.php'); break;
		}
		?>
		<div class="clear"></div>
	</div>
</div>
<div id="footer">&copy; 2014 - PT. Jaya Real Property, Tbk<br>Built By ASYS IT Consultant</div>
</body>
</html>
<?php close($conn); ?>