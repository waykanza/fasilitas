<?php
require_once('../../../../config/config.php');
die_login();
die_mod('LA3');
$conn = conn();
die_conn($conn);

$query_search = '';

$no_kwitansi			= (isset($_REQUEST['no_kwitansi'])) ? clean($_REQUEST['no_kwitansi']) : '';
$periode_tag			= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$jenis_tgl_bayar_bank	= (isset($_REQUEST['jenis_tgl_bayar_bank'])) ? clean($_REQUEST['jenis_tgl_bayar_bank']) : '';
$tgl_bayar_bank			= (isset($_REQUEST['tgl_bayar_bank'])) ? clean($_REQUEST['tgl_bayar_bank']) : '';
$jenis_tgl_bayar_sys	= (isset($_REQUEST['jenis_tgl_bayar_sys'])) ? clean($_REQUEST['jenis_tgl_bayar_sys']) : '';
$tgl_bayar_sys			= (isset($_REQUEST['tgl_bayar_sys'])) ? clean($_REQUEST['tgl_bayar_sys']) : '';
$cara_bayar				= (isset($_REQUEST['cara_bayar'])) ? clean($_REQUEST['cara_bayar']) : '';
$bayar_via				= (isset($_REQUEST['bayar_via'])) ? clean($_REQUEST['bayar_via']) : '';
$kode_sektor			= (isset($_REQUEST['kode_sektor'])) ? clean($_REQUEST['kode_sektor']) : '';
$kode_cluster			= (isset($_REQUEST['kode_cluster'])) ? clean($_REQUEST['kode_cluster']) : '';
$trx					= (isset($_REQUEST['trx'])) ? clean($_REQUEST['trx']) : '';
$aktif_air				= (isset($_REQUEST['aktif_air'])) ? clean($_REQUEST['aktif_air']) : '';
$aktif_ipl				= (isset($_REQUEST['aktif_ipl'])) ? clean($_REQUEST['aktif_ipl']) : '';
$user_bayar				= (isset($_REQUEST['user_bayar'])) ? clean($_REQUEST['user_bayar']) : '';
$order_field			= (isset($_REQUEST['order_field'])) ? clean($_REQUEST['order_field']) : '';
$order_type				= (isset($_REQUEST['order_type'])) ? clean($_REQUEST['order_type']) : '';

$desc_top = array();
$desc_bottom = array();

$desc_top[] = 'Laporan Rincian Penerimaan';

if ($kode_sektor != '') {
	$query_search .= " AND b.KODE_SEKTOR = '$kode_sektor' ";
	$desc_top[] = 'Sektor : ' . get_nama('sektor', $kode_sektor);
}
if ($kode_cluster != '') {
	$query_search .= " AND b.KODE_CLUSTER = '$kode_cluster' ";
	$desc_top[] = 'Cluster : ' . get_nama('cluster', $kode_cluster);
}
if ($trx != '') {
	$query_search .= " AND TRX = $trx ";
	$desc_top[] = 'Status : ' . status_blok($trx);
}
if ($no_kwitansi != '') {
	$query_search .= " AND NO_KWITANSI LIKE '%$no_kwitansi%' ";
	$desc_top[] = "KWT : $no_kwitansi";
}
if ($aktif_air != '') {
	$query_search .= " AND b.AKTIF_AIR = $aktif_air ";
	$desc_top[] = ($aktif_air == '1') ? 'Aktif Air ' : 'Tidak Aktif Air ';
}
if ($aktif_ipl != '') {
	$query_search .= " AND b.AKTIF_IPL = $aktif_ipl ";
	$desc_top[] = ($aktif_ipl == '1') ? 'Aktif IPL ' : 'Tidak Aktif IPL ';
}
if ($user_bayar != '') {
	$query_search .= " AND b.USER_BAYAR = '$user_bayar' ";
	$desc_bottom[] = 'Kasir : ' . get_nama('user', $user_bayar);
}
if ($periode_tag != '') {
	$query_search .= " AND b.PERIODE_TAG = '$periode_tag' ";
	$desc_top[] = 'Periode : ' . fm_periode($periode_tag);
}
if ($tgl_bayar_bank != '') {
	if ($jenis_tgl_bayar_bank == 'HARIAN') {
		$query_search .= " AND CONVERT(VARCHAR(10), b.TGL_BAYAR_BANK, 105) = '$tgl_bayar_bank' ";
		$desc_top[] = 'Tanggal Bayar : ' . fm_date($tgl_bayar_bank);
	} else {
		$query_search .= " AND RIGHT(CONVERT(VARCHAR(10), b.TGL_BAYAR_BANK, 105), 7) = '$tgl_bayar_bank' ";
		$desc_top[] = 'Bulan Bayar : ' . fm_periode(to_periode($tgl_bayar_bank));
	}
}
if ($tgl_bayar_sys != '') {
	if ($jenis_tgl_bayar_sys == 'HARIAN') {
		$query_search .= " AND CONVERT(VARCHAR(10), b.TGL_BAYAR_SYS, 105) = '$tgl_bayar_sys' ";
		$desc_top[] = 'Tanggal Terima Bank : ' . fm_date($tgl_bayar_sys);
	} else {
		$query_search .= " AND RIGHT(CONVERT(VARCHAR(10), b.TGL_BAYAR_SYS, 105), 7) = '$tgl_bayar_sys' ";
		$desc_top[] = 'Bulan Terima Bank : ' . fm_periode(to_periode($tgl_bayar_sys));
	}
}
if ($cara_bayar != '') {
	$query_search .= " AND b.CARA_BAYAR = $cara_bayar ";
	$desc_bottom[] = 'Cara Bayar : ' . cara_bayar($cara_bayar);
}
if ($bayar_via != '') {
	$query_search .= " AND b.BAYAR_VIA = '$bayar_via' ";
	$desc_bottom[] = get_nama('bank', $bayar_via);
}

$obj = get_parameter('JRP_PT, UNIT_NAMA, UNIT_ALAMAT_1, UNIT_ALAMAT_2, UNIT_KOTA, UNIT_KODE_POS');

$set_jrp = '
<tr><td colspan="23" class="nb"><b>' . $obj->fields['JRP_PT'] . '</b></td></tr>
<tr><td colspan="23" class="nb"><b>' . $obj->fields['UNIT_NAMA'] . '</b></td></tr>
<tr><td colspan="23" class="nb">' . $obj->fields['UNIT_ALAMAT_1'] . ' ' . $obj->fields['UNIT_ALAMAT_2'] . '</td></tr>
<tr><td colspan="23" class="nb">' . $obj->fields['UNIT_KOTA'] . ', ' . $obj->fields['UNIT_KODE_POS'] . '</td></tr>
<tr><td colspan="23" class="nb">&nbsp;</td></tr>
<tr>
	<td colspan="21" class="nb">
		' . implode(' | ', $desc_top) . '<br>' . implode(' | ', $desc_bottom) . '
	</td>
	<td colspan="2" class="nb text-right va-bottom">Halaman 1 dari 1</td>
</tr>

<tr>
	<th rowspan="2">NO.</th>
	<th rowspan="2">NO. TAGIHAN</th>
	<th rowspan="2">BLOK / NO.</th>
	<th rowspan="2">SEKTOR</th>
	<th rowspan="2">CLUSTER</th>
	<th rowspan="2">NAMA PELANGGAN</th>
	<th rowspan="2">NO. KWITANSI</th>
	<th rowspan="2">PERIODE</th>
	<th rowspan="2">JUMLAH<br>PERIODE</th>
	<th rowspan="2">TANGGAL<br>BAYAR<br>(BANK)</th>
	<th rowspan="2">AIR</th>
	<th rowspan="2">IPL</th>
	<th colspan="2">DISKON</th>
	<th rowspan="2">ADM</th>
	<th rowspan="2">PPN</th>
	<th rowspan="2">TOTAL<br>EXC. PPN</th>
	<th rowspan="2">DENDA</th>
	<th rowspan="2">TOTAL<br>BAYAR</th>
	<th rowspan="2">JENIS<br>BAYAR</th>
	<th rowspan="2">VALIDASI</th>
	<th rowspan="2">KET. BAYAR</th>
</tr>
<tr>
	<th>AIR</th>
	<th>IPL</th>
</tr>
';

$filename = "LAPORAN_RINCIAN_PENERIMAAN_$tgl_trx";

header("Content-type: application/msexcel");
header("Content-Disposition: attachment; filename=$filename.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $desc_top[0]; ?></title>
<style type="text/css">
@media print {
	@page {
		size:34.6cm 27.90cm;
	}
	.newpage {page-break-before:always;}
}

.newpage {margin-top:25px;}

table {
	font-family:Arial, Helvetica, sans-serif;
	width:100%;
	border-spacing:0;
	border-collapse:collapse;
}
table tr {
	font-size:11px;
	padding:2px;
}
table td {
	padding:2px;
	vertical-align:top;
}
table th.nb,
table td.nb {
	border:none !important;
}
table.data th {
	border:1px solid #000000;
}
table.data td {
	border-right:1px solid #000000;
	border-left:1px solid #000000;
}
tfoot tr {
	font-weight:bold;
	text-align:right;
	border:1px solid #000000;
}
.break { word-wrap:break-word; }
.nowrap { white-space:nowrap; }
.va-top { vertical-align:top; }
.va-bottom { vertical-align:bottom; }
.text-left { text-align:left; }
.text-center { text-align:center; }
.text-right { text-align:right; }
</style>
</head>
<body>

<table class="data">

<?php
echo $set_jrp;

	$query = "
	SELECT 
		b.NO_INVOICE,
		b.KODE_BLOK,
		s.NAMA_SEKTOR,
		c.NAMA_CLUSTER,
		p.NAMA_PELANGGAN,
		b.NO_KWITANSI,
		dbo.PTPS(b.PERIODE_TAG) AS PERIODE_TAG,
		b.JUMLAH_PERIODE_IPL,
		CONVERT(VARCHAR(10),b.TGL_BAYAR_BANK,105) AS TGL_BAYAR_BANK,
		
		b.JUMLAH_AIR,
		b.JUMLAH_IPL,
		b.DENDA,
		b.ADM,
		b.DISKON_AIR,
		b.DISKON_IPL,
		
		CASE WHEN b.NILAI_PPN = 0 
			THEN dbo.PPN(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA)) 
			ELSE b.NILAI_PPN
		END AS NILAI_PPN,
		
		CASE WHEN b.NILAI_PPN = 0 
			THEN (b.ADM + b.DENDA + dbo.DPP(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA)))
			ELSE (b.JUMLAH_BAYAR - b.NILAI_PPN)
		END AS EXC_PPN,
		
		b.JUMLAH_BAYAR,
		b.USER_BAYAR,
		b.CARA_BAYAR,
		b.BAYAR_VIA,
		b.KET_BAYAR
	FROM 
		KWT_PEMBAYARAN_AI b
		LEFT JOIN KWT_PELANGGAN p ON b.NO_PELANGGAN = p.NO_PELANGGAN
		LEFT JOIN KWT_SEKTOR s ON b.KODE_SEKTOR = s.KODE_SEKTOR
		LEFT JOIN KWT_CLUSTER c ON b.KODE_CLUSTER = c.KODE_CLUSTER
	WHERE
		$where_trx_air_ipl AND 
		b.STATUS_BAYAR = 1 
		$query_search
	ORDER BY $order_field $order_type
	";
	
	$obj = $conn->Execute($query);
	
	$i = 1;
	
	$sum_jumlah_air			= 0;
	$sum_jumlah_ipl			= 0;
	$sum_denda				= 0;
	$sum_adm				= 0;
	$sum_diskon_air			= 0;
	$sum_diskon_ipl			= 0;
	$sum_nilai_ppn			= 0;
	$sum_exc_ppn			= 0;
	$sum_jumlah_bayar		= 0;
	
	while( ! $obj->EOF)
	{		
		?>
		<tr> 
			<td class="text-center"><?php echo $i; ?></td>
			<td><?php echo $obj->fields['NO_INVOICE']; ?></td>
			<td class="nowrap"><?php echo $obj->fields['KODE_BLOK']; ?></td>
			<td><?php echo $obj->fields['NAMA_SEKTOR']; ?></td>
			<td><?php echo $obj->fields['NAMA_CLUSTER']; ?></td>
			<td><?php echo $obj->fields['NAMA_PELANGGAN']; ?></td>
			<td class="text-right"><?php echo $obj->fields['NO_KWITANSI']; ?></td>
			<td class="text-center nowrap"><?php echo $obj->fields['PERIODE_TAG']; ?></td>
			<td class="text-center nowrap"><?php echo $obj->fields['JUMLAH_PERIODE_IPL']; ?></td>
			<td class="text-center nowrap"><?php echo $obj->fields['TGL_BAYAR_BANK']; ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_AIR']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_IPL']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['DISKON_AIR']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['DISKON_IPL']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['ADM']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['NILAI_PPN']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['EXC_PPN']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['DENDA']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_BAYAR']); ?></td>
			<td class="nowrap"><?php echo cara_bayar($obj->fields['CARA_BAYAR'], $obj->fields['BAYAR_VIA']); ?></td>
			<td><?php echo $obj->fields['USER_BAYAR']; ?></td>
			<td><?php echo $obj->fields['KET_BAYAR']; ?></td>
		</tr>
		<?php
		
		$sum_jumlah_air			+= $obj->fields['JUMLAH_AIR'];
		$sum_jumlah_ipl			+= $obj->fields['JUMLAH_IPL'];
		$sum_denda				+= $obj->fields['DENDA'];
		$sum_adm				+= $obj->fields['ADM'];
		$sum_diskon_air			+= $obj->fields['DISKON_AIR'];
		$sum_diskon_ipl			+= $obj->fields['DISKON_IPL'];
		$sum_nilai_ppn			+= $obj->fields['NILAI_PPN'];
		$sum_exc_ppn			+= $obj->fields['EXC_PPN'];
		$sum_jumlah_bayar		+= $obj->fields['JUMLAH_BAYAR'];
		
		$i++;
		
		$obj->movenext();
	}
?>
<tfoot>
<tr>
	<td colspan="10">TOTAL .........</td>
	<td><?php echo to_money($sum_jumlah_air); ?></td>
	<td><?php echo to_money($sum_jumlah_ipl); ?></td>
	<td><?php echo to_money($sum_diskon_air); ?></td>
	<td><?php echo to_money($sum_diskon_ipl); ?></td>
	<td><?php echo to_money($sum_adm); ?></td>
	<td><?php echo to_money($sum_nilai_ppn); ?></td>
	<td><?php echo to_money($sum_exc_ppn); ?></td>
	<td><?php echo to_money($sum_denda); ?></td>
	<td><?php echo to_money($sum_jumlah_bayar); ?></td>
	<td colspan="3"></td>
</tr>
</tfoot>
	
</table>
</body>
</html>
<?php
close($conn);
exit;
?>