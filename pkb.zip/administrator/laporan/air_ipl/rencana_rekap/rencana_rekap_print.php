<?php
require_once('../../../../config/config.php');
die_login();
die_mod('LA2');
$conn = conn();
die_conn($conn);

$query_search = '';

$periode_tag	= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$jenis_rekap	= (isset($_REQUEST['jenis_rekap'])) ? clean($_REQUEST['jenis_rekap']) : '';
$kode_sektor	= (isset($_REQUEST['kode_sektor'])) ? clean($_REQUEST['kode_sektor']) : '';
$trx			= (isset($_REQUEST['trx'])) ? clean($_REQUEST['trx']) : '';
$aktif_air		= (isset($_REQUEST['aktif_air'])) ? clean($_REQUEST['aktif_air']) : '';
$aktif_ipl		= (isset($_REQUEST['aktif_ipl'])) ? clean($_REQUEST['aktif_ipl']) : '';

$desc_top = array();
$desc_bottom = array();

$desc_top[] = 'Laporan Rekap Rencana Penerimaan';

if ($jenis_rekap == 'RS') {
	$th_sek_clu = 'SEKTOR';
	$query_group = 'KODE_SEKTOR';
	$query_header = "(SELECT ISNULL(NAMA_SEKTOR, q.KODE_SEKTOR) FROM KWT_SEKTOR WHERE KODE_SEKTOR = q.KODE_SEKTOR)";
	$query_lokasi = 'KWT_SEKTOR ';
} else {
	$th_sek_clu = 'CLUSTER';
	$query_group = 'KODE_CLUSTER';
	$query_header = "(SELECT ISNULL(NAMA_CLUSTER, q.KODE_CLUSTER) FROM KWT_CLUSTER WHERE KODE_CLUSTER = q.KODE_CLUSTER)";
	$query_lokasi = 'KWT_CLUSTER ';
}
if ($kode_sektor != '') {
	$query_search .= " AND b.KODE_SEKTOR = '$kode_sektor' ";
	$desc_top[] = 'Sektor : ' . get_nama('sektor', $kode_sektor);
	$query_lokasi .= " WHERE KODE_SEKTOR = '$kode_sektor' ";
}

if ($trx != '')
{
	$query_search .= " AND TRX = $trx ";
	$desc_top[] = 'Status : ' . status_blok($trx);
}
if ($aktif_air != '') {
	$query_search .= " AND b.AKTIF_AIR = $aktif_air ";
	$desc_top[] = ($aktif_air == '1') ? 'Aktif Air ' : 'Tidak Aktif Air ';
}
if ($aktif_ipl != '') {
	$query_search .= " AND b.AKTIF_IPL = $aktif_ipl ";
	$desc_top[] = ($aktif_ipl == '1') ? 'Aktif IPL ' : 'Tidak Aktif IPL ';
}

$desc_top[] = 'Periode : ' . fm_periode($periode_tag);

$obj = get_parameter('JRP_PT, UNIT_NAMA, UNIT_ALAMAT_1, UNIT_ALAMAT_2, UNIT_KOTA, UNIT_KODE_POS');

$set_jrp = '
<tr><td colspan="11" class="nb"><b>' . $obj->fields['JRP_PT'] . '</b></td></tr>
<tr><td colspan="11" class="nb"><b>' . $obj->fields['UNIT_NAMA'] . '</b></td></tr>
<tr><td colspan="11" class="nb">' . $obj->fields['UNIT_ALAMAT_1'] . ' ' . $obj->fields['UNIT_ALAMAT_2'] . '</td></tr>
<tr><td colspan="11" class="nb">' . $obj->fields['UNIT_KOTA'] . ', ' . $obj->fields['UNIT_KODE_POS'] . '</td></tr>
<tr><td colspan="11" class="nb">&nbsp;</td></tr>
<tr>
	<td colspan="9" class="nb">
		' . implode(' | ', $desc_top) . '
	</td>
	<td colspan="2" class="nb text-right va-bottom">Halaman 1 dari 1</td>
</tr>

<tr>
	<th rowspan="2">NO.</th>
	<th rowspan="2">' . $th_sek_clu . '</th>
	<th rowspan="2">PEMAKAIAN</th>
	<th rowspan="2">AIR</th>
	<th rowspan="2">ABONEMEN</th>
	<th rowspan="2">IPL</th>
	<th rowspan="2">ADM</th>
	<th colspan="2">DISKON</th>
	<th rowspan="2">DENDAN</th>
	<th rowspan="2">JML. BAYAR</th>
</tr>
<tr>
	<th>AIR</th>
	<th>IPL</th>
</tr>
';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $desc_top[0]; ?></title>
<style type="text/css">
@media print {
	@page {
		size:34.6cm 27.90cm;
	}
	.newpage {page-break-before:always;}
}

.newpage {margin-top:25px;}

table {
	font-family:Arial, Helvetica, sans-serif;
	width:100%;
	border-spacing:0;
	border-collapse:collapse;
}
table tr {
	font-size:11px;
	padding:2px;
}
table td {
	padding:2px;
}
table th.nb,
table td.nb {
	border:none !important;
}
table.data th {
	border:1px solid #000000;
}
table.data td {
	border-right:1px solid #000000;
	border-left:1px solid #000000;
}
tfoot tr {
	font-weight:bold;
	text-align:right;
	border:1px solid #000000;
}
.break { 
	word-wrap:break-word; 
}
.nowrap {
	white-space:nowrap;
}
.text-left {
	text-align:left;
}
.text-center {
	text-align:center;
}
.text-right {
	text-align:right;
}
</style>
</head>
<body onload="window.print()">

<table class="data">

<?php
echo $set_jrp;

$obj = $conn->Execute("
SELECT TOP 1 
ADM_KV, ADM_BG,
ADM_HN, ADM_RV
FROM KWT_PARAMETER");

$adm_kv = $obj->fields['ADM_KV'];
$adm_bg = $obj->fields['ADM_BG'];
$adm_hn = $obj->fields['ADM_HN'];
$adm_rv = $obj->fields['ADM_RV'];

$query = "
SELECT
	$query_header AS NAMA_LOKASI,
	SUM(q.PEMAKAIAN) AS PEMAKAIAN,
	SUM(q.JUMLAH_AIR) AS JUMLAH_AIR,
	SUM(q.DENDA) AS DENDA,
	SUM(q.ABONEMEN) AS ABONEMEN,
	SUM(q.JUMLAH_IPL) AS JUMLAH_IPL,
	SUM(q.DENDA) AS DENDA,
	SUM(q.ADM) AS ADM,
	SUM(q.DISKON_AIR) AS DISKON_AIR,
	SUM(q.DISKON_IPL) AS DISKON_IPL,
	SUM(q.JUMLAH_TAGIHAN) AS JUMLAH_TAGIHAN
FROM 
(
	SELECT 
		$query_group,
		0 AS PEMAKAIAN,
		0 AS JUMLAH_AIR,
		0 AS ABONEMEN,
		0 AS JUMLAH_IPL,
		0 AS DENDA,
		0 AS ADM,
		0 AS DISKON_AIR,
		0 AS DISKON_IPL,
		0 AS JUMLAH_TAGIHAN
	FROM $query_lokasi

	UNION ALL

	SELECT 
		$query_group AS query_group,
		SUM((b.STAND_AKHIR - b.STAND_LALU + b.STAND_ANGKAT) + b.STAND_MIN_PAKAI) AS PEMAKAIAN,
		SUM(b.JUMLAH_AIR) AS JUMLAH_AIR,
		SUM(b.ABONEMEN) AS ABONEMEN,
		SUM(b.JUMLAH_IPL) AS JUMLAH_IPL,
		SUM(b.DENDA) AS DENDA,
		SUM(
			CASE WHEN b.STATUS_BAYAR = 1 THEN b.ADM ELSE 
			CASE TRX
				WHEN $trx_kv THEN $adm_kv 
				WHEN $trx_bg THEN $adm_bg 
				WHEN $trx_hn THEN $adm_hn 
				WHEN $trx_rv THEN $adm_rv 
			END END 
		) AS ADM,
		SUM(b.DISKON_AIR) AS DISKON_AIR,
		SUM(b.DISKON_IPL) AS DISKON_IPL,
		SUM(
			b.JUMLAH_AIR + b.JUMLAH_IPL + b.ABONEMEN + b.DENDA + 
			CASE WHEN b.STATUS_BAYAR = 1 THEN b.ADM ELSE 
			CASE TRX
				WHEN $trx_kv THEN $adm_kv 
				WHEN $trx_bg THEN $adm_bg 
				WHEN $trx_hn THEN $adm_hn 
				WHEN $trx_rv THEN $adm_rv 
			END END 
			- b.DISKON_AIR - b.DISKON_IPL
		) AS JUMLAH_TAGIHAN
	FROM 
		KWT_PEMBAYARAN_AI b
	WHERE
		$where_trx_air_ipl AND 
		b.PERIODE_TAG = '$periode_tag'
		$query_search
	GROUP BY b.$query_group
) q
GROUP BY q.$query_group
ORDER BY q.$query_group ASC
";

$obj = $conn->Execute($query);

$i = 1;

$sum_pemakaian			= 0;
$sum_jumlah_air			= 0;
$sum_abonemen			= 0;
$sum_jumlah_ipl			= 0;
$sum_denda				= 0;
$sum_jumlah_adm = 0;
$sum_diskon_air	= 0;
$sum_diskon_ipl 	= 0;
$sum_jumlah_tagihan		= 0;

while( ! $obj->EOF)
{		
	?>
	<tr> 
		<td class="text-center"><?php echo $i; ?></td>
		<td><?php echo $obj->fields['NAMA_LOKASI']; ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['PEMAKAIAN']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_AIR']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['ABONEMEN']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_IPL']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['ADM']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['DISKON_AIR']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['DISKON_IPL']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['DENDA']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_TAGIHAN']); ?></td>
	</tr>
	<?php
	
	$sum_pemakaian			+= $obj->fields['PEMAKAIAN'];
	$sum_jumlah_air			+= $obj->fields['JUMLAH_AIR'];
	$sum_abonemen			+= $obj->fields['ABONEMEN'];
	$sum_jumlah_ipl			+= $obj->fields['JUMLAH_IPL'];
	$sum_jumlah_adm			+= $obj->fields['ADM'];
	$sum_diskon_air			+= $obj->fields['DISKON_AIR'];
	$sum_diskon_ipl			+= $obj->fields['DISKON_IPL'];
	$sum_denda				+= $obj->fields['DENDA'];
	$sum_jumlah_tagihan		+= $obj->fields['JUMLAH_TAGIHAN'];
	
	$i++;
	$obj->movenext();
}
?>
<tfoot>
<tr>
	<td colspan="2">GRAND TOTAL .........</td>
	<td><?php echo to_money($sum_pemakaian); ?></td>
	<td><?php echo to_money($sum_jumlah_air); ?></td>
	<td><?php echo to_money($sum_abonemen); ?></td>
	<td><?php echo to_money($sum_jumlah_ipl); ?></td>
	<td><?php echo to_money($sum_jumlah_adm); ?></td>
	<td><?php echo to_money($sum_diskon_air); ?></td>
	<td><?php echo to_money($sum_diskon_ipl); ?></td>
	<td><?php echo to_money($sum_denda); ?></td>
	<td><?php echo to_money($sum_jumlah_tagihan); ?></td>
</tr>
</tfoot>
</table>

</body>
</html>
<?php
close($conn);
exit;
?>