<?php
require_once('../../../../config/config.php');
die_login();
die_mod('LA4');
$conn = conn();
die_conn($conn);

$query_search = '';

$jenis_rekap	= (isset($_REQUEST['jenis_rekap'])) ? clean($_REQUEST['jenis_rekap']) : '';
$no_kwitansi	= (isset($_REQUEST['no_kwitansi'])) ? clean($_REQUEST['no_kwitansi']) : '';
$tgl_bayar_bank	= (isset($_REQUEST['tgl_bayar_bank'])) ? clean($_REQUEST['tgl_bayar_bank']) : '';
$tgl_bayar_sys	= (isset($_REQUEST['tgl_bayar_sys'])) ? clean($_REQUEST['tgl_bayar_sys']) : '';
$cara_bayar		= (isset($_REQUEST['cara_bayar'])) ? clean($_REQUEST['cara_bayar']) : '';
$bayar_via		= (isset($_REQUEST['bayar_via'])) ? clean($_REQUEST['bayar_via']) : '';
$kode_sektor	= (isset($_REQUEST['kode_sektor'])) ? clean($_REQUEST['kode_sektor']) : '';
$trx			= (isset($_REQUEST['trx'])) ? clean($_REQUEST['trx']) : '';
$aktif_air		= (isset($_REQUEST['aktif_air'])) ? clean($_REQUEST['aktif_air']) : '';
$aktif_ipl		= (isset($_REQUEST['aktif_ipl'])) ? clean($_REQUEST['aktif_ipl']) : '';
$user_bayar		= (isset($_REQUEST['user_bayar'])) ? clean($_REQUEST['user_bayar']) : '';

$tgl_rekap = '';

if ($kode_sektor != '') {
	$query_search .= " AND b.KODE_SEKTOR = '$kode_sektor' ";
}
if ($trx != '') {
	$query_search .= " AND TRX = $trx ";
}
if ($no_kwitansi != '') {
	$query_search .= " AND NO_KWITANSI LIKE '%$no_kwitansi%' ";
}
if ($aktif_air != '') {
	$query_search .= " AND b.AKTIF_AIR = $aktif_air ";
}
if ($aktif_ipl != '') {
	$query_search .= " AND b.AKTIF_IPL = $aktif_ipl ";
}
if ($user_bayar != '') {
	$query_search .= " AND b.USER_BAYAR = '$user_bayar' ";
}
if ($tgl_bayar_bank != '' AND $jenis_rekap == 'TGL_BAYAR_BANK') {
	$tgl_rekap = $tgl_bayar_bank;
	$query_search .= " AND RIGHT(CONVERT(VARCHAR(10), b.TGL_BAYAR_BANK, 105), 7) = '$tgl_bayar_bank' ";
}
if ($tgl_bayar_sys != '' AND $jenis_rekap == 'TGL_BAYAR_SYS') {
	$tgl_rekap = $tgl_bayar_sys;
	$query_search .= " AND RIGHT(CONVERT(VARCHAR(10), b.TGL_BAYAR_SYS, 105), 7) = '$tgl_bayar_sys' ";
}
if ($cara_bayar != '') {
	$query_search .= " AND b.CARA_BAYAR = $cara_bayar ";
}
if ($bayar_via != '') {
	$query_search .= " AND b.BAYAR_VIA = '$bayar_via' ";
}
?>

<table id="pagging-1" class="t-control">
<tr>
	<td>
		<input type="button" id="excel" value=" Excel (Alt+X) ">
		<input type="button" id="print" value=" Print (Alt+P) ">
	</td>
</tr>
</table>

<?php
$max_tgl = (int) date('t', strtotime(to_periode($tgl_rekap) . '01'));

$x = array();
for ($x = 1; $x <= $max_tgl; $x++)
{
	$xjumlah_air[$x] = 0;
	$xjumlah_ipl[$x] = 0;
	$xdenda[$x] = 0;
	$xadm[$x] = 0;
	$xdiskon_air[$x] = 0;
	$xdiskon_ipl[$x] = 0;
	$xnilai_ppn[$x] = 0;
	$xexc_ppn[$x] = 0;
	$xjumlah_bayar[$x] = 0;
}

$query = "
SELECT 
	CONVERT(VARCHAR(2), $jenis_rekap, 105) AS TANGGAL,
	
	SUM(b.JUMLAH_AIR) AS JUMLAH_AIR,
	SUM(b.JUMLAH_IPL) AS JUMLAH_IPL,
	SUM(b.DENDA) AS DENDA,
	SUM(b.ADM) AS ADM,
	SUM(b.DISKON_AIR) AS DISKON_AIR,
	SUM(b.DISKON_IPL) AS DISKON_IPL,
	
	SUM(CASE WHEN b.NILAI_PPN = 0 
			THEN dbo.PPN(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA)) 
			ELSE b.NILAI_PPN
		END) AS NILAI_PPN,
		
	SUM(CASE WHEN b.NILAI_PPN = 0 
			THEN (b.ADM + b.DENDA + dbo.DPP(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA)))
			ELSE (b.JUMLAH_BAYAR - b.NILAI_PPN)
		END) AS EXC_PPN,
		
	SUM(b.JUMLAH_BAYAR) AS JUMLAH_BAYAR
FROM 
	KWT_PEMBAYARAN_AI b
WHERE
	$where_trx_air_ipl AND 
	b.STATUS_BAYAR = 1
	$query_search
GROUP BY CONVERT(VARCHAR(2), $jenis_rekap, 105)
";

$obj = $conn->Execute($query);
$sum_jumlah_air = 0;
$sum_jumlah_ipl = 0;
$sum_denda = 0;
$sum_adm = 0;
$sum_diskon_air = 0;
$sum_diskon_ipl = 0;
$sum_nilai_ppn = 0;
$sum_exc_ppn = 0;
$sum_jumlah_bayar = 0;

while( ! $obj->EOF)
{
	$i = (int) $obj->fields['TANGGAL'];
	
	$xjumlah_air[$i]		= $obj->fields['JUMLAH_AIR'];
	$xjumlah_ipl[$i]		= $obj->fields['JUMLAH_IPL'];
	$xdenda[$i]				= $obj->fields['DENDA'];
	$xadm[$i]		= $obj->fields['ADM'];
	$xdiskon_air[$i]		= $obj->fields['DISKON_AIR'];
	$xdiskon_ipl[$i]		= $obj->fields['DISKON_IPL'];
	$xnilai_ppn[$i]			= $obj->fields['NILAI_PPN'];
	$xexc_ppn[$i]			= $obj->fields['EXC_PPN'];
	$xjumlah_bayar[$i]		= $obj->fields['JUMLAH_BAYAR'];
	
	$sum_jumlah_air			+= $xjumlah_air[$i];
	$sum_jumlah_ipl			+= $xjumlah_ipl[$i];
	$sum_denda				+= $xdenda[$i];
	$sum_adm				+= $xadm[$i];
	$sum_diskon_air			+= $xdiskon_air[$i];
	$sum_diskon_ipl			+= $xdiskon_ipl[$i];
	$sum_nilai_ppn			+= $xnilai_ppn[$i];
	$sum_exc_ppn			+= $xexc_ppn[$i];
	$sum_jumlah_bayar		+= $xjumlah_bayar[$i];
	
	$obj->movenext();
}
?>

<table class="t-data t-nowarp wm100">
<tr>
	<th rowspan="2" width="150">TANGGAL</th>
	<th rowspan="2">AIR</th>
	<th rowspan="2">IPL</th>
	<th rowspan="2">ADM</th>
	<th colspan="2">DISKON</th>
	<th rowspan="2">PPN</th>
	<th rowspan="2">TOTAL<br>EXC. PPN</th>
	<th rowspan="2">DENDA</th>
	<th rowspan="2">TOTAL<br>BAYAR</th>
</tr>
<tr>
	<th>AIR</th>
	<th>IPL</th>
</tr>
<?php
$fm_periode = fm_periode(to_periode($tgl_rekap), '%b %Y');

foreach ($xjumlah_bayar AS $k => $v)
{
	?>
	<tr> 
		<td class="text-center"><?php echo $k.' '.$fm_periode; ?></td>
		<td class="text-right"><?php echo to_money($xjumlah_air[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xjumlah_ipl[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xadm[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xdiskon_air[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xdiskon_ipl[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xnilai_ppn[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xexc_ppn[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xdenda[$k]); ?></td>
		<td class="text-right"><?php echo to_money($xjumlah_bayar[$k]); ?></td>
	</tr>
	<?php
}
?>
<tfoot>
<tr>
	<td>GRAND TOTAL .........</td>
	<td><?php echo to_money($sum_jumlah_air); ?></td>
	<td><?php echo to_money($sum_jumlah_ipl); ?></td>
	<td><?php echo to_money($sum_adm); ?></td>
	<td><?php echo to_money($sum_diskon_air); ?></td>
	<td><?php echo to_money($sum_diskon_ipl); ?></td>
	<td><?php echo to_money($sum_nilai_ppn); ?></td>
	<td><?php echo to_money($sum_exc_ppn); ?></td>
	<td><?php echo to_money($sum_denda); ?></td>
	<td><?php echo to_money($sum_jumlah_bayar); ?></td>
</tr>
</tfoot>
</table>

<table id="pagging-2" class="t-control"></table>

<script type="text/javascript">
jQuery(function($) {
	$('#pagging-2').html($('#pagging-1').html());
	t_strip('.t-data');
});
</script>

<?php
close($conn);
exit;
?>