<div class="title-page">PENOMORAN FAKTUR PAJAK</div>

<form name="form" id="form" method="post">
<table class="t-control">
<tr>
	<td width="120">PERIODE TAG.</td>
	<td><input type="text" name="periode_tag" id="periode_tag" size="10" class="apply mm-yyyy" value=""></td>
</tr>

<tr>
	<td>TGL. FAKTUR PAJAK</td>
	<td><input type="text" name="tgl_fp" id="tgl_fp" size="12" class="apply dd-mm-yyyy" value=""></td>
</tr>

<tr>
	<td>COUNTER START</td>
	<td><input type="text" name="cou_fp" id="cou_fp" size="15" value=""></td>
</tr>

<tr>
	<td>LIMIT</td>
	<td><input type="text" name="limit_fp" id="limit_fp" size="5" value=""></td>
</tr>

<tr>
	<td>TOTAL DATA</td>
	<td id="total-data"></td>
</tr>

<tr>
	<td></td>
	<td>
		<input type="button" id="apply" value=" Tampilkan ">
		<input type="button" name="save" id="save" value=" Simpan ">
	</td>
</tr>
</table>

<script type="text/javascript">
jQuery(function($) {
	
	$('#cou_fp, #limit_fp').inputmask('integer');
	
	$(document).on('keypress', '.apply', function(e) {
		var code = (e.keyCode ? e.keyCode : e.which);
		if (code == 13) { $('#apply').trigger('click'); return false; }
	});
	
	$(document).on('keypress', '.proses', function(e) {
		var code = (e.keyCode ? e.keyCode : e.which);
		if (code == 13) { $('#proses').trigger('click'); return false; }
	});
	
	/* -- BUTTON -- */
	$(document).on('click', '#apply', function(e) {
		e.preventDefault();
		
		var periode = $('#periode_tag').val(),
			tgl_fp = $('#tgl_fp').val();
		if (periode == '') {
			alert('Masukkan periode');
			$('#periode_tag').focus();
			return false;
		} else if (tgl_fp == '') {
			alert('Masukkan tanggal faktur pajak');
			$('#tgl_fp').focus();
			return false;
		}
		
		$('#t-detail').load(base_faktur_pajak + 'penomoran/penomoran_load.php', $('#form').serialize());
		
		return false;
	});
	
	/* SAVE */
	$(document).on('click', '#save', function(e) {
		
		var periode = $('#periode_tag').val(),
			tgl_fp = $('#tgl_fp').val();
		if (periode == '') {
			alert('Masukkan periode');
			$('#periode_tag').focus();
			return false;
		} else if (tgl_fp == '') {
			alert('Masukkan tanggal faktur pajak');
			$('#tgl_fp').focus();
			return false;
		}
		
		$.post(base_faktur_pajak + 'penomoran/penomoran_save.php', jQuery('#form').serialize(), function(data) {
			
			alert(data.msg);
			
		}, 'json');
		
		return false;
	});
	
});
</script>

<div id="t-detail"></div>
</form>