<?php
require_once('../../../config/config.php');
die_login();
die_mod('U5');
$conn = conn();
die_conn($conn);


$per_page	= (isset($_REQUEST['per_page'])) ? max(1, $_REQUEST['per_page']) : 20;
$page_num	= (isset($_REQUEST['page_num'])) ? max(1, $_REQUEST['page_num']) : 1;

$periode_tag	= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$tgl_fp			= (isset($_REQUEST['tgl_fp'])) ? $_REQUEST['tgl_fp'] : '';
$cou_fp			= (isset($_REQUEST['cou_fp'])) ? to_number($_REQUEST['cou_fp']) : '0';
$limit_fp		= (isset($_REQUEST['limit_fp'])) ? to_number($_REQUEST['limit_fp']) : '0';

$query = "
SELECT
	COUNT(b.ID_PEMBAYARAN) AS TOTAL 
FROM 
	KWT_PEMBAYARAN_AI b
	LEFT JOIN KWT_PELANGGAN p ON b.NO_PELANGGAN = p.NO_PELANGGAN
WHERE
	$where_trx_ppn AND 
	b.PERIODE_TAG = '$periode_tag' AND 
	b.STATUS_BAYAR = 1 AND 
	b.TGL_POST_FP IS NULL AND 
	(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL) > 0 
";
$total_data = $conn->Execute($query)->fields['TOTAL'];

?>

<table class="t-data">
<tr>
	<th>NO.</th>
	<th>KODE BLOK</th>
	<th>NAMA PELANGGAN</th>
	<th>NO. FAKTUR</th>
	<th>TANGGAL FAKTUR</th>
	<th>PPN</th>
	<th>DPP</th>
	<th>TOTAL TAGIHAN</th>
	<th>JUMLAH BAYAR</th>
</tr>

<?php

$reg_fp = $conn->Execute("SELECT TOP 1 REG_FP FROM KWT_PARAMETER")->fields['REG_FP'];

$query = "
SELECT TOP $limit_fp
	b.KODE_BLOK, 
	p.NAMA_PELANGGAN,
	'$reg_fp' AS NO_FP,
	CONVERT(VARCHAR(10), b.TGL_FP, 105) AS TGL_FP,
	dbo.PPN(b.PERSEN_PPN, (b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL)) AS NILAI_PPN, 
	dbo.DPP(b.PERSEN_PPN, (b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL)) AS NILAI_DPP, 
	(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL + b.ADM + b.DENDA - b.DISKON_AIR - b.DISKON_IPL) AS TOTAL_TAGIHAN, 
	b.JUMLAH_BAYAR
FROM 
	KWT_PEMBAYARAN_AI b
	LEFT JOIN KWT_PELANGGAN p ON b.NO_PELANGGAN = p.NO_PELANGGAN
WHERE
	$where_trx_ppn AND 
	b.PERIODE_TAG = '$periode_tag' AND 
	b.TGL_POST_FP IS NULL AND 
	(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL) > 0 
ORDER BY b.KODE_BLOK
";

$obj = $conn->Execute($query);
$i = 1;
while( ! $obj->EOF)
{
	?>
	<tr> 
		<td class="text-center"><?php echo $i; ?></td>
		<td><?php echo $obj->fields['KODE_BLOK']; ?></td>
		<td><?php echo $obj->fields['NAMA_PELANGGAN']; ?></td>
		<td><?php echo $obj->fields['NO_FP'] . $cou_fp; ?></td>
		<td class="text-center"><?php echo $tgl_fp; ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['NILAI_PPN']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['NILAI_DPP']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['TOTAL_TAGIHAN']); ?></td>
		<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_BAYAR']); ?></td>
	</tr>
	<?php
	$cou_fp++;
	$i++;
	$obj->movenext();
}
?>
</table>

<script type="text/javascript">
jQuery(function($) {
	$('#total-data').html('<?php echo $total_data; ?>');
	
	t_strip('.t-data');
});
</script>

<?php
close($conn);
exit;
?>