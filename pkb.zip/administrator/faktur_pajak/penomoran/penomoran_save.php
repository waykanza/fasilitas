<?php
require_once('../../../config/config.php');
die_login();
die_mod('U5');
$conn = conn();
die_conn($conn);

$msg = '';
$error = FALSE;

$periode_tag	= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$tgl_fp			= (isset($_REQUEST['tgl_fp'])) ? to_date($_REQUEST['tgl_fp']) : '';
$cou_fp			= (isset($_REQUEST['cou_fp'])) ? to_number($_REQUEST['cou_fp']) : '1';
$limit_fp		= (isset($_REQUEST['limit_fp'])) ? to_number($_REQUEST['limit_fp']) : '1';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
	try 
	{
		$conn->begintrans();
		
		ex_empty($periode_tag, 'Masukkan periode!');
		
		$query = "
		SELECT 
			COUNT(b.ID_PEMBAYARAN) AS TOTAL
		FROM 
			KWT_PEMBAYARAN_AI b
		WHERE
			$where_trx_ppn AND 
			b.PERIODE_TAG = '$periode_tag' AND 
			b.TGL_POST_FP IS NULL AND 
			(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL) > 0 
		";
		ex_not_found($conn->Execute($query)->fields['TOTAL'], "Data pembayaran tidak tidemukan.");

		$reg_fp = $conn->Execute("SELECT TOP 1 REG_FP FROM KWT_PARAMETER")->fields['REG_FP'];
		
		$query = "
		DECLARE 
		@cou_fp INT = ($cou_fp - 1),
		@id_pembayaran VARCHAR(100)
		
		DECLARE curid CURSOR LOCAL FOR 
		(
			SELECT TOP $limit_fp ID_PEMBAYARAN 
			FROM KWT_PEMBAYARAN_AI b
			WHERE
				$where_trx_ppn AND 
				b.PERIODE_TAG = '$periode_tag' AND 
				b.TGL_POST_FP IS NULL AND 
				(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL - b.DISKON_AIR - b.DISKON_IPL) > 0 
		)

		OPEN curid
		FETCH NEXT FROM curid INTO @id_pembayaran
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @cou_fp = @cou_fp + 1
			
			UPDATE KWT_PEMBAYARAN_AI
			SET
				NO_FP = '$reg_fp' + CAST(@cou_fp AS VARCHAR), 
				TGL_FP = '$tgl_fp',
				NILAI_PPN = dbo.PPN(PERSEN_PPN, (JUMLAH_AIR + ABONEMEN + JUMLAH_IPL - DISKON_AIR - DISKON_IPL)), 
					
				USER_MODIFIED = '$sess_id_user', 
				MODIFIED_DATE = GETDATE() 
			WHERE
				$where_trx_ppn AND 
				ID_PEMBAYARAN = @id_pembayaran
				
			FETCH NEXT FROM curid INTO @id_pembayaran
		END

		CLOSE curid
		DEALLOCATE curid
		";

		ex_false($conn->Execute($query), $query);
		
		$conn->committrans();
		
		$msg = 'No faktur pajak berhasil diproses.';
	}
	catch(Exception $e)
	{
		$msg = $e->getmessage();
		$error = TRUE;
		$conn->rollbacktrans();
	}
}

close($conn);
$json = array('msg' => $msg, 'error'=> $error);
echo json_encode($json);
exit;
?>