<?php
require_once('../../../config/config.php');
die_login();
die_mod('U6');
$conn = conn();
die_conn($conn);

$query_search = '';

$per_page	= (isset($_REQUEST['per_page'])) ? max(1, $_REQUEST['per_page']) : 20;
$page_num	= (isset($_REQUEST['page_num'])) ? max(1, $_REQUEST['page_num']) : 1;

$periode_tag	= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$kode_sektor	= (isset($_REQUEST['kode_sektor'])) ? clean($_REQUEST['kode_sektor']) : '';
$kode_cluster	= (isset($_REQUEST['kode_cluster'])) ? clean($_REQUEST['kode_cluster']) : '';
$trx			= (isset($_REQUEST['trx'])) ? clean($_REQUEST['trx']) : '';

if ($kode_sektor != '')
{
	$query_search .= " AND b.KODE_SEKTOR = '$kode_sektor' ";
}
if ($kode_cluster != '')
{
	$query_search .= " AND b.KODE_CLUSTER = '$kode_cluster' ";
}
if ($trx != '')
{
	$query_search .= " AND TRX = $trx ";
}

# Pagination
$query = "
SELECT 
	COUNT(b.ID_PEMBAYARAN) AS TOTAL 
FROM 
	KWT_PEMBAYARAN_AI b 
WHERE 
	$where_trx_ppn AND 
	b.PERIODE_TAG = '$periode_tag' AND 
	b.TGL_POST_FP IS NOT NULL 
	$query_search
";
$total_data = $conn->Execute($query)->fields['TOTAL'];
$total_page = ceil($total_data/$per_page);

$page_num = ($page_num > $total_page) ? $total_page : $page_num;
$page_start = (($page_num-1) * $per_page);
# End Pagination
?>

<table id="pagging-1" class="t-control">
<tr>
	<td>
		<input type="button" id="print" value=" Cetak (Alt+P) ">
	</td>
	
	<td class="text-right">
		<input type="button" id="prev_page" value=" < (Alt+Left) ">
		Hal : <input type="text" name="page_num" size="5" class="page_num apply text-center" value="<?php echo $page_num; ?>">
		Dari <?php echo $total_page ?> 
		<input type="hidden" id="total_page" value="<?php echo $total_page; ?>">
		<input type="button" id="next_page" value=" (Alt+Right) > ">
	</td>
</tr>
</table>

<table class="t-data">
<tr>
	<th rowspan="2"><input type="checkbox" id="cb_all"></th>
	<th rowspan="2">NO.</th>
	<th rowspan="2">NO. PELANGGAN</th>
	<th colspan="3">BLOK</th>
	<th rowspan="2">NAMA PELANGGAN</th>
	<th rowspan="2">NO. FAKTUR PAJAK</th>
	<th colspan="4">NILAI</th>
	<th colspan="3">INVOICE</th>
</tr>
<tr>
	<th>KODE BLOK</th>
	<th>STATUS</th>
	<th>TAGIHAN</th>
	<th>PPN</th>
	<th>DPP</th>
	<th>TOTAL TAGIHAN</th>
	<th>JUMLAH BAYAR</th>
	<th>CETAK</th>
	<th>TGL.</th>
	<th>USER</th>
</tr>

<?php
if ($total_data > 0)
{
	$query = "
	SELECT 
		b.ID_PEMBAYARAN, 
		b.NO_PELANGGAN,
		b.KODE_BLOK, 
		b.STATUS_BLOK, 
		b.TRX, 
		(CASE WHEN p.AKTIF_SM = 1 THEN p.SM_NAMA_PELANGGAN ELSE p.NAMA_PELANGGAN END) AS NAMA_PELANGGAN,
		b.NO_FP,
		CONVERT(VARCHAR(10),b.TGL_FP,105) AS TGL_FP, 
		
		b.NILAI_PPN, 
		dbo.DPP(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA)) AS NILAI_DPP, 
		(b.JUMLAH_AIR + b.ABONEMEN + b.JUMLAH_IPL + b.ADM + b.DENDA - b.DISKON_AIR - b.DISKON_IPL) AS TOTAL_TAGIHAN, 
		b.JUMLAH_BAYAR,
	
		STATUS_CETAK_FP, 
		CONVERT(VARCHAR(10),b.TGL_CETAK_FP,105) AS TGL_CETAK_FP, 
		uc.NAMA_USER AS USER_CETAK_FP
	FROM 
		KWT_PEMBAYARAN_AI b
		LEFT JOIN KWT_PELANGGAN p ON b.NO_PELANGGAN = p.NO_PELANGGAN
		
		LEFT JOIN KWT_USER uc ON b.USER_CETAK_FP = uc.ID_USER 
	WHERE
		$where_trx_ppn AND 
		b.PERIODE_TAG = '$periode_tag' AND
		b.TGL_POST_FP IS NOT NULL
		$query_search
	ORDER BY b.KODE_BLOK 
	";
	$obj = $conn->SelectLimit($query, $per_page, $page_start);
	
	$i = 1 + $page_start;
	while( ! $obj->EOF)
	{
		$id = base64_encode($obj->fields['ID_PEMBAYARAN']);
		?>
		<tr id="<?php echo $id; ?>"> 
			<td width="30" class="text-center"><input type="checkbox" name="cb_data[]" class="cb_data" value="<?php echo $id; ?>"></td>
			<td class="text-center"><?php echo $i; ?></td>
			<td><?php echo fm_nopel($obj->fields['NO_PELANGGAN']); ?></td>
			<td><?php echo $obj->fields['KODE_BLOK']; ?></td>
			<td><?php echo status_blok($obj->fields['STATUS_BLOK']); ?></td>
			<td><?php echo status_trx($obj->fields['TRX']); ?></td>
			<td><?php echo $obj->fields['NAMA_PELANGGAN']; ?></td>
			<td><?php echo $obj->fields['NO_FP']; ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['NILAI_PPN']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['NILAI_DPP']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['TOTAL_TAGIHAN']); ?></td>
			<td class="text-right"><?php echo to_money($obj->fields['JUMLAH_BAYAR']); ?></td>
			<td class="text-center"><?php echo status_check($obj->fields['STATUS_CETAK_FP']); ?></td>
			<td class="text-center"><?php echo $obj->fields['TGL_CETAK_FP']; ?></td>
			<td><?php echo $obj->fields['USER_CETAK_FP']; ?></td>
		</tr>
		<?php
		$i++;
		$obj->movenext();
	}
}
?>
</table>

<table id="pagging-2" class="t-control"></table>

<script type="text/javascript">
jQuery(function($) {
	$('#pagging-2').html($('#pagging-1').html());
	
	$('#total-data').html('<?php echo $total_data; ?>');
	$('#per_page').val('<?php echo $per_page; ?>');
	$('.page_num').inputmask('integer');
	t_strip('.t-data');
});
</script>

<?php
close($conn);
exit;
?>