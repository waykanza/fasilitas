<?php
require_once('../../../config/config.php');
require_once('../../../config/terbilang.php');
die_login();
die_mod('U6');
$conn = conn();
die_conn($conn);

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style type="text/css">
	@page {
		size: A4;
		margin: 0;
	}
	@media print {
		.wrap {
			margin: 0;
			width: initial;
			min-height: initial;
			background: initial;
			page-break-after: always;
		}
	}
	
	* {
		font-size: 12px;
		font-family: Verdana, Geneva, sans-serif;
		border-color: transparent !important;
	}
	
	.wrap {
		width: 21cm;
		min-height: 29.7cm;
		padding: 2cm;
		margin: 1cm auto;
		background: none;
	}
	
	.hr-top {
		margin:10px 0;
		border: none;
		background: #000;
		height:2px;
	}
	
	table {
		width: 100%;
		border-collapse: collapse;
		border: 1px solid black;
	}
	table tr td {
		font-size: 12px;
		padding: 4px 10px;
		vertical-align:top;
		border:none;
	}
	
	table.tb-top tr td {
		padding: 2px 10px 2px 0px;
	}
	
	.tr-sum td {
		padding:0px;
	}
	.hr-sum {
		margin:0 3px 0 0;
		border: none;
		background: black;
		height:1px;
	}
	
	ol {
		margin: 0px;
		padding-left:25px;
	}
	
	ol li {
		font-size: 12px;
		margin-top: 2px;
		margin-bottom: 2px;
	}
	
	.f-left { float: left; }
	.f-right { float: right; }
	.clear { clear: both; }
	.text-left { text-align: left; }
	.text-right { text-align: right; }
	.text-center { text-align: center; }
	.va-top { vertical-align:top; }
	.bd-none { border: none; }
	.bd-all { border: 1px solid black; }
	.bd-top { border-top: 1px solid black; }
	.bd-right { border-right: 1px solid black; }
	.bd-bottom { border-bottom: 1px solid black; }
	.bd-left { border-left: 1px solid black; }
</style>
</head>

<body onload="window.print()">
<?php
$terbilang = new Terbilang;

$obj			= $conn->Execute("SELECT JRP_PT, JRP_ALAMAT_1, JRP_ALAMAT_2, REG_NPWP, NAMA_PAJAK, JBT_PAJAK FROM KWT_PARAMETER");

$jrp_pt			= $obj->fields['JRP_PT'];
$jrp_alamat_1	= $obj->fields['JRP_ALAMAT_1'];
$jrp_alamat_2	= $obj->fields['JRP_ALAMAT_2'];
$reg_npwp		= $obj->fields['REG_NPWP'];
$nama_pajak		= $obj->fields['NAMA_PAJAK'];
$jbt_pajak		= $obj->fields['JBT_PAJAK'];

$cb_data = (isset($_REQUEST['cb_data'])) ? $_REQUEST['cb_data'] : array();

$in_id_pembayaran = array();
foreach ($cb_data as $x) { $in_id_pembayaran[] = base64_decode($x); }
$in_id_pembayaran = implode("' ,'", $in_id_pembayaran);

$query = "
SELECT
	(CASE WHEN p.AKTIF_SM = 1 THEN p.SM_NAMA_PELANGGAN ELSE p.NAMA_PELANGGAN END) AS NAMA_PELANGGAN,
	(CASE WHEN p.AKTIF_SM = 1 THEN p.SM_ALAMAT ELSE p.ALAMAT END) AS ALAMAT,
	(CASE WHEN p.AKTIF_SM = 1 THEN p.SM_NPWP ELSE p.NPWP END) AS NPWP,
	
	b.NO_FP,
	CONVERT(VARCHAR(19),b.TGL_FP,120) AS TGL_FP,
	
	b.NO_INVOICE,
	b.KODE_BLOK,
	
	b.PERSEN_PPN, 
	(dbo.DPP(b.PERSEN_PPN, (b.JUMLAH_BAYAR - b.ADM - b.DENDA))) AS NILAI_DPP, 
	b.NILAI_PPN,
	
	b.TRX,
	b.AKTIF_AIR,
	b.AKTIF_IPL,
	
	b.KET_IVC
FROM 
	KWT_PEMBAYARAN_AI b
	LEFT JOIN KWT_PELANGGAN p ON b.NO_PELANGGAN = p.NO_PELANGGAN
WHERE
	$where_trx_ppn AND 
	b.ID_PEMBAYARAN IN ('$in_id_pembayaran')
ORDER BY b.KODE_BLOK
";
	
$obj = $conn->Execute($query);

while( ! $obj->EOF)
{
	$nama_pelanggan		= $obj->fields['NAMA_PELANGGAN'];
	$alamat				= $obj->fields['ALAMAT'];
	$npwp				= $obj->fields['NPWP'];
	
	$no_fp				= $obj->fields['NO_FP'];
	$tgl_fp				= $obj->fields['TGL_FP'];
	
	$no_invoice			= $obj->fields['NO_INVOICE'];
	$kode_blok			= $obj->fields['KODE_BLOK'];
	
	$persen_ppn			= $obj->fields['PERSEN_PPN'];
	$nilai_dpp			= $obj->fields['NILAI_DPP'];
	$nilai_ppn			= $obj->fields['NILAI_PPN'];

	$trx				= $obj->fields['TRX'];
	$aktif_air			= $obj->fields['AKTIF_AIR'];
	$aktif_ipl			= $obj->fields['AKTIF_IPL'];
	
	$ket_ivc			= $obj->fields['KET_IVC'];

	$text = '';
	
	if ($trx == $trx_kv || $trx == $trx_bg || $trx == $trx_hn || $trx == $trx_rv) 
	{
		if ($aktif_ipl == '1') { 
			$text = $text . ' Iuran Pemeliharaan Lingkungan';
			if ($aktif_air == '1') { 
				$text = $text . ' dan Air Bersih';
			} 
		} elseif ($aktif_air == '1') { 
			$text = $text . ' Iuran Pemeliharaan Lingkungan';
		} 
		
		if ($trx == $trx_kv) { $text = $text . ' Kavling Kosong<br>'; }
		elseif ($trx == $trx_bg) { $text = $text . ' Masa Membangun<br>'; }
		elseif ($trx == $trx_hn) { $text = $text . ' Hunian<br>'; }
		elseif ($trx == $trx_rv) { $text = $text . ' Renovasi<br>'; }
	}
	elseif ($trx == $trx_lbg || $trx == $trx_lrv) 
	{
		$text = $text . ' Biaya Lain-lain';
		
		if ($trx == $trx_lbg) { $text = $text . " Masa Membangun ($ket_ivc)<br>"; }
		elseif ($trx == $trx_lrv) { $text = $text . " Renovasi ($ket_ivc)<br>"; }
	}
	
	$text = $text . " Blok. $kode_blok<br>Invoice : $no_invoice";

	?>
	<div class="wrap">
	
	<div class="text-center"><h2 style="font-size:1.5em;">&nbsp;</h2></div>
	
	<table border="1" class="bd-all" style="width:100%;"><tr><td style="padding:0px;">
		
		<table class="bd-none">
			<tr><td class="bd-bottom" style="padding-left:200px;"><?php echo $no_fp; ?>&nbsp;</td></tr>
			<tr><td class="bd-bottom">&nbsp;</td></tr>
			<tr><td style="padding-left:180px;">PT. JAYA REAL PROPERTY&nbsp;</td></tr>
			<tr><td style="padding-left:180px;"><?php echo $jrp_alamat_1 . '<br>' . $jrp_alamat_2; ?>&nbsp;</td></tr>
			<tr><td style="padding-left:180px;"><?php echo $reg_npwp; ?>&nbsp;</td></tr>
		</table>
		
		<br><br><br>
		
		<table class="bd-none">
			<tr><td class="bd-top bd-bottom">&nbsp;</td></tr>
		</table>
		
		<table class="bd-none">
			<tr><td style="padding-left:180px;"><?php echo $nama_pelanggan; ?>&nbsp;</td></tr>
			<tr><td style="padding-left:180px;"><?php echo $alamat; ?>&nbsp;</td></tr>
			<tr><td style="padding-left:180px;"><?php echo $npwp; ?>&nbsp;</td></tr>
		</table>
		
		<br>
		
		<table class="bd-none">
			<tr>
				<td width="20" class="text-center bd-top bd-right">&nbsp;<br>&nbsp;</td>
				<td class="text-center bd-top bd-right">&nbsp;</td>
				<td class="text-center bd-top">&nbsp;<br>&nbsp;</td>
			</tr>
			<tr height="250">
				<td class="text-center bd-top bd-right"><br>1</td>
				<td class="bd-top bd-right"><br><?php echo $text; ?>&nbsp;</td>
				<td class="text-right bd-top"><br><?php echo to_money($nilai_dpp); ?></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top bd-right">&nbsp;</td>
				<td class="text-right bd-top"><?php echo to_money($nilai_dpp); ?></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top bd-right">&nbsp;</td>
				<td class="text-right bd-top"></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top bd-right">&nbsp;</td>
				<td class="text-right bd-top"></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top bd-right">&nbsp;</td>
				<td class="text-right bd-top"><?php echo to_money($nilai_dpp); ?></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top bd-right">
					&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;
					<?php echo to_money($persen_ppn); ?>
				</td>
				<td class="text-right bd-top"><?php echo to_money($nilai_ppn); ?></td>
			</tr>
			<tr>
				<td colspan="2" class="bd-top">&nbsp;</td>
				<td class="text-right bd-top">
					Tangerang, 
					&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;
					<?php echo fm_date($tgl_fp, '%d %b %Y'); ?>
					
				</td>
			</tr>
		</table>
		
		<table class="bd-none">
			<tr>
				<td width="50" class="text-center bd-top bd-right bd-top">&nbsp;</td>
				<td width="120" class="text-center bd-right bd-top">&nbsp;</td>
				<td width="120" class="text-center bd-right bd-top">&nbsp;</td>
				<td></td>
			</tr>
			<tr><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td></tr>
			<tr><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td></tr>
			<tr><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td></tr>
			<tr><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td><td class="bd-right bd-top">&nbsp;</td></tr>
			<tr>
				<td colspan="2" class="bd-right bd-top bd-bottom">&nbsp;</td>
				<td class="bd-right bd-top bd-bottom">&nbsp;</td>
				<td class="text-right"><?php echo $nama_pajak; ?>&nbsp;</td>
			</tr>
		</table>
		
		<br>
		
	</td></tr></table>	
	</div>

	<div class="newpage"></div>
	<?php
	$obj->movenext();
}

$conn->Execute("
UPDATE KWT_PEMBAYARAN_AI 
SET 
	STATUS_CETAK_FP = 1, 
	TGL_CETAK_FP = GETDATE(), 
	USER_CETAK_FP = '$sess_id_user', 
	
	USER_MODIFIED = '$sess_id_user', 
	MODIFIED_DATE = GETDATE() 
WHERE ID_PEMBAYARAN IN ('$in_id_pembayaran')");
?>

</body>
</html>

<?php close($conn); ?>

