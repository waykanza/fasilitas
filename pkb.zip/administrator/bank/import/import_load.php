<?php
require_once('../../../config/config.php');
die_login();
die_mod('B2');
$conn = conn();
die_conn($conn);

$nama_bank = (isset($_REQUEST['nama_bank'])) ? clean($_REQUEST['nama_bank']) : '';

switch ($nama_bank)
{
	case 'BCA'			: $ext = 'txt'; $bayar_via = 'BC'; $user_bayar = '2'; $ket_bayar = 'TRF BCA'; break;
	case 'BUKOPIN'		: $ext = 'xls'; $bayar_via = 'BK'; $user_bayar = '2'; $ket_bayar = 'TRF BUKOPIN'; break;
	#case 'BUKOPIN_AD'	: $ext = 'xls'; $bayar_via = 'XX'; $user_bayar = '3'; $ket_bayar = 'AD BUKOPIN'; break;
	case 'BUMIPUTERA'	: $ext = 'xls'; $bayar_via = 'BB'; $user_bayar = '2'; $ket_bayar = 'TRF BUMIPUTERA'; break;
	case 'MANDIRI'		: $ext = 'xls'; $bayar_via = 'BM'; $user_bayar = '2'; $ket_bayar = 'TRF MANDIRI'; break;
	case 'NIAGA'		: $ext = 'txt'; $bayar_via = 'BN'; $user_bayar = '2'; $ket_bayar = 'TRF NIAGA'; break;
	case 'NIAGA_AD'		: $ext = 'txt'; $bayar_via = 'BN'; $user_bayar = '3'; $ket_bayar = 'AD NIAGA'; break;
	case 'PERMATA'		: $ext = 'txt'; $bayar_via = 'BP'; $user_bayar = '2'; $ket_bayar = 'TRF PERMATA'; break;
}

if ($nama_bank == '')
{
	echo '<script type="text/javascript">alert("Proses import untuk bank yang anda pilih belum tersedia.");</script>';
}
else
{
	$path = IMPORT_PATH . strtolower($nama_bank) . '\\';
	
	?>
	<table class="t-control">
	<tr>
		<td>
			<input type="button" id="save" value=" Simpan Data Pembayaran ">
		</td>
	</tr>
	</table>

	<form name="form-data" id="form-data" method="post">
	<table class="t-data">
	<tr>
		<th rowspan="2">NO.</th>
		<th rowspan="2"><input type="checkbox" id="cb_all"></th>
		<th rowspan="2">NO. PELANGGAN</th>
		<th rowspan="2">NAMA PELANGGAN</th>
		<th rowspan="2">KODE BLOK</th>
		<th rowspan="2">TANGGAL<br>BAYAR</th>
		<th colspan="4">TAGIHAN</th>
		<th rowspan="2">JUMLAH<br>BAYAR<br>(<?php echo date('M-Y'); ?>)</th>
		<th rowspan="2">JUMLAH<br>BAYAR<br>(IMPORT)</th>
		<th rowspan="2">SELISIH</th>
		<th rowspan="2">KETERANGAN</th>
	</tr>
	<tr>
		<th class="">AIR & IPL</th>
		<th class="">DEPOSIT</th>
		<th class="">LAIN-LAIN</th>
		<th class="">TOTAL</th>
	</tr>
	<?php

	$uploaded_file = $path . "upload.$ext";
	if ( ! file_exists($uploaded_file))
	{
		echo '<tr><td colspan="14">Error. File import tidak ditemukan.</td></tr>';
		exit;
	}
	
	require_once('../../../config/excel_reader.php');
	require_once('data_'. strtolower($nama_bank) .'.php');
	
	require_once('load_data.php');
}

close($conn);
?>

<input type="hidden" name="user_bayar" id="user_bayar" value="<?php echo $user_bayar; ?>">
<input type="hidden" name="bayar_via" id="bayar_via" value="<?php echo $bayar_via; ?>">
<input type="hidden" name="ket_bayar" id="ket_bayar" value="<?php echo $ket_bayar; ?>">
</form>

<script type="text/javascript">
jQuery(function($) {
	t_strip('.t-data');
});
</script>