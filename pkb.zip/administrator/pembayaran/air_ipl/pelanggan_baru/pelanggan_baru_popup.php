<?php
require_once('../../../../config/config.php');
die_login();
die_mod('PA2');
$conn = conn();
die_conn($conn);

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<!-- CSS -->
<link type="text/css" href="../../../../config/css/style.css" rel="stylesheet">
<link type="text/css" href="../../../../plugin/css/zebra/default.css" rel="stylesheet">
<link type="text/css" href="../../../../plugin/window/themes/default.css" rel="stylesheet">
<link type="text/css" href="../../../../plugin/window/themes/mac_os_x.css" rel="stylesheet">

<!-- JS -->
<script type="text/javascript" src="../../../../plugin/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="../../../../plugin/js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="../../../../plugin/js/jquery.inputmask.custom.js"></script>
<script type="text/javascript" src="../../../../plugin/js/keymaster.js"></script>
<script type="text/javascript" src="../../../../plugin/js/zebra_datepicker.js"></script>
<script type="text/javascript" src="../../../../plugin/window/javascripts/prototype.js"></script>
<script type="text/javascript" src="../../../../plugin/window/javascripts/window.js"></script>
<script type="text/javascript" src="../../../../config/js/main.js"></script>
<script type="text/javascript">
jQuery(function($) {
	
	key('alt+c', function(e) { e.preventDefault(); $('#find_pelanggan').trigger('click'); });
	
	key('alt+s', function(e) { e.preventDefault(); $('#save').trigger('click'); });
	key('alt+r', function(e) { e.preventDefault(); $('#reset').trigger('click'); });
	key('esc', function(e) { e.preventDefault(); $('#close').trigger('click'); });
	
	$('#stand_akhir, #stand_lalu').inputmask('numeric', { repeat: '10' });
	$('#pemakaian').inputmask('numeric', { repeat: '10', allowMinus: true });
	
	$('#stand_akhir, #stand_lalu').on('change', function(e) {
		e.preventDefault();
		
		var stand_akhir	= $('#stand_akhir').val(),
			stand_lalu	= $('#stand_lalu').val();

		stand_akhir = stand_akhir.replace(/[^0-9.]/g, '');
		stand_lalu = stand_lalu.replace(/[^0-9.]/g, '');
		
		stand_akhir = (stand_akhir == '') ? 0 : parseFloat(stand_akhir);
		stand_lalu = (stand_lalu == '') ? 0 : parseFloat(stand_lalu);
		
		var pemakaian = (stand_akhir - stand_lalu);
		
		$('#pemakaian').val(pemakaian);
	});
	
	$('#close').on('click', function(e) {
		e.preventDefault();
		return parent.loadData();
	});
	
	$('#reset').on('click', function(e) {
		e.preventDefault();
		$('#no_pelanggan').val('');
		$('#td-nama_pelanggan, #td-nama_sektor, #td-nama_cluster, #td-kode_blok, #td-key_air, #td-key_ipl').empty();
		$('#stand_akhir, #stand_lalu, #pemakaian').val('');
	});
	
	$('#save').on('click', function(e) {
		e.preventDefault();
		
		var periode = $('#periode_tag').val(),
			no_pelanggan = $('#no_pelanggan').val(),
			pemakaian	= $('#pemakaian').val(),
			pemakaian	= pemakaian.replace(/[^-0-9.]/g, ''),
			pemakaian	= (pemakaian == '') ? 0 : parseFloat(pemakaian);
			
		if (periode == '')
		{
			alert('Masukkan periode pemakaian.');
			$('#periode_tag').focus();
			return false;
		}
		else if (no_pelanggan == '')
		{
			alert('Pilih pelangan.');
			$('#no_pelanggan').focus();
			return false;
		}
		else if (pemakaian < 0)
		{
			alert('Pemakaian tidak boleh minus..');
			$('#stand_akhir').focus();
			return false;
		}
		
		var url		= base_pembayaran + 'air_ipl/pelanggan_baru/pelanggan_baru_proses.php',
			data	= $('#form').serialize();
			
		$.post(url, data, function(data) {
			
			alert(data.msg);
			if (data.error == false)
			{
				$('#reset').trigger('click');
			}
		}, 'json');
		
		return false;
	});
	
	$('#find_pelanggan').on('click', function(e) {
		e.preventDefault();
		var periode = $('#periode_tag').val();
		if (periode == '')
		{
			alert('Masukkan periode pembayaran (Awal).');
			$('#periode_tag').focus();
			return false;
		}
		
		var url = base_pembayaran + 'air_ipl/pelanggan_baru/find_pelanggan.php?periode=' + periode;
		
		setPopup('Cari Pelanggan', url, winWidth-100, 500);
		
		return false;
	});
	
});
</script>
</head>
<body class="popup">

<form name="form" id="form" method="post">
<table class="t-popup w50 f-left">
<tr>
	<td width="150">PERIODE TAG.</td><td width="10">:</td>
	<td><input type="text" name="periode_tag" id="periode_tag" class="mm-yyyy" size="10" value="">&nbsp;&nbsp;* Periode tagihan</td>
</tr>
<tr>
	<td>PERIODE AWAL (IPL)</td><td>:</td>
	<td><input type="text" name="periode_ipl_awal" id="periode_ipl_awal" class="mm-yyyy" size="10" value=""></td>
</tr>
<tr>
	<td>JML. PERIODE (IPL)</td><td>:</td>
	<td><input type="text" name="jumlah_periode_ipl" id="jumlah_periode_ipl" class="text-center" size="2" value="1"></td>
</tr>
<tr>
	<td>TGL. JATUH TEMPO</td><td>:</td>
	<td><input type="text" name="tgl_jatuh_tempo" id="tgl_jatuh_tempo" class="dd-mm-yyyy" size="12"></td>
</tr>
<tr>
	<td>STAND AKHIR</td><td>:</td>
	<td><input type="text" name="stand_akhir" id="stand_akhir" size="10" value=""></td>
</tr>
<tr>
	<td>STAND LALU</td><td>:</td>
	<td><input type="text" name="stand_lalu" id="stand_lalu" size="10" value=""></td>
</tr>
<tr>
	<td>PEMAKAIAN</td><td>:</td>
	<td><input readonly="readonly" type="text" id="pemakaian" size="10" value=""></td>
</tr>
<tr>
	<td colspan="3">
		<br>
		<input type="button" id="save" value=" Simpan (Alt+S) ">
		<input type="reset" id="reset" value=" Reset (Alt+R) ">
		<input type="button" id="close" value=" Tutup (Esc) ">&nbsp;
	</td>
</tr>
</table>

<table class="t-popup w50 f-right">
<tr>
	<td width="150">NO. PELANGGAN</td><td width="10">:</td>
	<td>
		<input readonly="readonly" type="text" name="no_pelanggan" id="no_pelanggan" value="">
		<input type="hidden" name="trx" id="trx" value="">
		<input type="button" id="find_pelanggan" value=" Cari (Alt+C) ">
	</td>
</tr>
<tr>
	<td>NAMA PELANGGAN</td><td>:</td>
	<td id="td-nama_pelanggan"></td>
</tr>
<tr>
	<td>SEKTOR</td><td>:</td>
	<td id="td-nama_sektor"></td>
</tr>
<tr>
	<td>CLUSTER</td><td>:</td>
	<td id="td-nama_cluster"></td>
</tr>
<tr>
	<td>KODE BLOK</td><td>:</td>
	<td id="td-kode_blok"></td>
</tr>
<tr>
	<td>KODE TARIF AIR</td><td>:</td>
	<td id="td-key_air"></td>
</tr>
<tr>
	<td>KODE TARIF IPL</td><td>:</td>
	<td id="td-key_ipl"></td>
</tr>
</table>
</form>

</body>
</html>
<?php close($conn); ?>