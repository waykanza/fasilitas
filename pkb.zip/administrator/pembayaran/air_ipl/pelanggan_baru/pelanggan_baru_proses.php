<?php
require_once('../../../../config/config.php');
die_login();
die_mod('PA2');
$conn = conn();
die_conn($conn);

$msg = '';
$error = FALSE;

$periode_tag		= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
$periode_ipl_awal	= (isset($_REQUEST['periode_ipl_awal'])) ? to_periode($_REQUEST['periode_ipl_awal']) : '';
$jumlah_periode_ipl	= (isset($_REQUEST['jumlah_periode_ipl'])) ? to_number($_REQUEST['jumlah_periode_ipl']) : '1';
$tgl_jatuh_tempo	= (isset($_REQUEST['tgl_jatuh_tempo'])) ? to_date($_REQUEST['tgl_jatuh_tempo']) : '';

$no_pelanggan	= (isset($_REQUEST['no_pelanggan'])) ? clean($_REQUEST['no_pelanggan']) : '';
$trx			= (isset($_REQUEST['trx'])) ? clean($_REQUEST['trx']) : '';
$stand_akhir	= (isset($_REQUEST['stand_akhir'])) ? to_number($_REQUEST['stand_akhir']) : '';
$stand_lalu		= (isset($_REQUEST['stand_lalu'])) ? to_number($_REQUEST['stand_lalu']) : '';
	
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	try
	{
		$conn->begintrans();
		
		ex_empty($periode_tag, 'Periode awal.');
		ex_empty($no_pelanggan, 'Pilih pelanggan.');
		ex_empty($trx, 'Error Trx.');
		
		$pemakaian = (int) ($stand_akhir - $stand_lalu);
		ex_less($pemakaian, 0, 'Pemakaian tidak boleh minus!');
		
		
		if ($jumlah_periode_ipl == '' || $jumlah_periode_ipl == 0) {
			$jumlah_periode_ipl = 1;
		}
		if ($periode_ipl_awal == '') {
			$periode_ipl_awal = $periode_tag;
		}
		
		# PERIODE AIR
		$periode_air = periode_mod('-1', $periode_tag);
		# $periode_air_prev = periode_mod('-1', $periode_air);
		
		# PERIODE IPL
		$periode_ipl_akhir = periode_mod('+' . ($jumlah_periode_ipl - 1), $periode_ipl_awal);
		
		$id_pembayaran = $trx . '#' . $periode_tag . '#' . $no_pelanggan;
		
		$query = "
		SELECT COUNT(ID_PEMBAYARAN) AS TOTAL 
		FROM KWT_PEMBAYARAN_AI p
		WHERE ID_PEMBAYARAN = '$id_pembayaran' 
		";
		ex_found($conn->Execute($query)->fields['TOTAL'], "Nomor pelanggan \"$no_pelanggan\" telah terdaftar di tagihan periode $periode_tag!");
		
		$query = "
		SELECT 
			p.NO_PELANGGAN,
			p.KODE_SEKTOR,
			p.KODE_CLUSTER,
			p.KODE_BLOK,
			p.KODE_ZONA,
			
			p.AKTIF_AIR,
			p.AKTIF_IPL,
			
			a.KEY_AIR,
			i.KEY_IPL,
			
			p.STATUS_BLOK,
			p.LUAS_KAVLING,
			
			a.ABONEMEN,
			a.BLOK1, 
			a.BLOK2, 
			a.BLOK3, 
			a.BLOK4, 
			
			a.STAND_MIN_PAKAI,
			a.TARIF1, 
			a.TARIF2, 
			a.TARIF3, 
			a.TARIF4,
			
			i.TARIF_IPL,
			i.TIPE_TARIF_IPL
		FROM 
			KWT_PELANGGAN p
			LEFT JOIN KWT_TARIF_AIR a ON p.KEY_AIR = a.KEY_AIR
			LEFT JOIN KWT_TARIF_IPL i ON p.KEY_IPL = i.KEY_IPL
		WHERE 
			p.DISABLED = 0 AND 
			p.NO_PELANGGAN = '$no_pelanggan'
		";

		$obj = $conn->Execute($query);
		
		$kode_sektor	= $obj->fields['KODE_SEKTOR'];
		$kode_cluster	= $obj->fields['KODE_CLUSTER'];
		$kode_blok		= $obj->fields['KODE_BLOK'];
		$kode_zona		= $obj->fields['KODE_ZONA'];
		$status_blok	= $obj->fields['STATUS_BLOK'];
		
		$aktif_air		= $obj->fields['AKTIF_AIR'];
		$aktif_ipl		= $obj->fields['AKTIF_IPL'];
		
		$key_air		= $obj->fields['KEY_AIR'];
		$key_ipl		= $obj->fields['KEY_IPL'];
		
		$blok1				= 0; 
		$blok2				= 0; 
		$blok3				= 0; 
		$blok4				= 0;
		$stand_min_pakai	= 0;
		
		$tarif1				= 0;
		$tarif2				= 0;
		$tarif3				= 0;
		$tarif4				= 0;
		$tarif_min_pakai	= 0;
		
		$abonemen			= 0;
		$jumlah_air			= 0;
		
		$luas_kavling		= 0;
		$tarif_ipl			= 0;
		$jumlah_ipl			= 0;
		
		if ($aktif_air == '0' AND $aktif_ipl == '0') {
			throw new Exception("Pelanggan tidak aktif air & IPL");
		}
		
		if ($aktif_ipl != '0') {
			ex_empty($key_ipl, "Kode tarif IPL tidak terdaftar di Master IPL -> Tarif.");
			
			$tipe_tarif_ipl = $obj->fields['TIPE_TARIF_IPL'];
			$luas_kavling	= $obj->fields['LUAS_KAVLING'];
			$tarif_ipl		= $obj->fields['TARIF_IPL'];
		
			if ($tipe_tarif_ipl == '1') {
				$jumlah_ipl = (int) ($luas_kavling * $tarif_ipl * $jumlah_periode_ipl);
			} else {
				$jumlah_ipl = (int) $tarif_ipl;
			}
		}
		
		if ($aktif_air != '0')
		{
			ex_empty($key_air, "Kode tarif air tidak terdaftar di Master Air -> Tarif.");
			
			$limit_blok1 = (int) $obj->fields['BLOK1'];
			$limit_blok2 = (int) $obj->fields['BLOK2'];
			$limit_blok3 = (int) $obj->fields['BLOK3'];
			$limit_blok4 = (int) $obj->fields['BLOK4'];
			$limit_stand_min_pakai = (int) $obj->fields['STAND_MIN_PAKAI'];
			$tarif1 = (int) $obj->fields['TARIF1'];
			$tarif2 = (int) $obj->fields['TARIF2'];
			$tarif3 = (int) $obj->fields['TARIF3'];
			$tarif4 = (int) $obj->fields['TARIF4'];
			$abonemen = (int) $obj->fields['ABONEMEN'];
			
			if ($pemakaian < $limit_stand_min_pakai) {
				$stand_min_pakai = $limit_stand_min_pakai - $pemakaian;
				$tarif_min_pakai = $tarif1;
			}
			
			if ($pemakaian > $limit_blok1) { 
				$blok1 = $limit_blok1; 
				$pemakaian -= $blok1;
				
				if ($pemakaian > ($limit_blok2 - $limit_blok1)) { 
					$blok2 = ($limit_blok2 - $limit_blok1); 
					$pemakaian -= ($limit_blok2 - $limit_blok1);
				
					if ($pemakaian > ($limit_blok3 - $limit_blok2)) { 
						$blok3 = ($limit_blok3 - $limit_blok2); 
						$pemakaian -= ($limit_blok3 - $limit_blok2);
				
						$blok4 = max(0, $pemakaian);
						
					} else { $blok3 = max(0, $pemakaian); }
				} else { $blok2 = max(0, $pemakaian); }
			} else { $blok1 = max(0, $pemakaian); }
			
			$jumlah_air = ($blok1 * $tarif1) + ($blok2 * $tarif2) + ($blok3 * $tarif3) + ($blok4 * $tarif4) + ($stand_min_pakai * $tarif_min_pakai);
		} 
		
		$ket_ivc = "PELANGGAN BARU PERIODE $periode_tag";
		
		$query = "
		DECLARE @persen_ppn NUMERIC(5,2) = (SELECT TOP 1 PERSEN_PPN FROM KWT_PARAMETER) 
		
		INSERT INTO KWT_PEMBAYARAN_AI
		(
			ID_PEMBAYARAN,
			TRX,
			
			PERIODE_TAG,
			PERIODE_AIR,
			PERIODE_IPL_AWAL,
			PERIODE_IPL_AKHIR,
			JUMLAH_PERIODE_IPL,
			TGL_JATUH_TEMPO,
			
			NO_PELANGGAN,
			
			KODE_SEKTOR,
			KODE_CLUSTER,
			KODE_BLOK,
			STATUS_BLOK,
			KODE_ZONA,
			
			AKTIF_AIR,
			AKTIF_IPL,
			
			KEY_AIR,
			KEY_IPL,
			
			STAND_AKHIR,
			STAND_LALU,
			
			BLOK1, 
			BLOK2, 
			BLOK3, 
			BLOK4, 
			STAND_MIN_PAKAI, 
			TARIF1, 
			TARIF2, 
			TARIF3, 
			TARIF4, 
			TARIF_MIN_PAKAI, 
			
			ABONEMEN, 
			JUMLAH_AIR,
			
			LUAS_KAVLING,
			TARIF_IPL,
			JUMLAH_IPL,
			
			PERSEN_PPN,
			
			KET_IVC, 
			
			USER_CREATED
		)
		VALUES
		(
			'$id_pembayaran',
			$trx,		
			
			'$periode_tag', 
			'$periode_air', 
			(CASE WHEN $aktif_ipl = 1 THEN '$periode_ipl_awal' ELSE '$periode_ipl_awal' END),
			(CASE WHEN $aktif_ipl = 1 THEN '$periode_ipl_akhir' ELSE '$periode_ipl_akhir' END),
			(CASE WHEN $aktif_ipl = 1 THEN '$jumlah_periode_ipl' ELSE '$jumlah_periode_ipl' END),
			'$tgl_jatuh_tempo',
			
			'$no_pelanggan',
			
			'$kode_sektor', 
			'$kode_cluster', 
			'$kode_blok', 
			'$status_blok', 
			'$kode_zona', 
			
			$aktif_air,
			$aktif_ipl,
			
			'$key_air', 
			'$key_ipl', 
			
			$stand_akhir, 
			$stand_lalu, 
			
			$blok1, 
			$blok2, 
			$blok3, 
			$blok4, 
			$stand_min_pakai, 
			$tarif1, 
			$tarif2, 
			$tarif3, 
			$tarif4, 
			$tarif_min_pakai, 
			
			$abonemen, 
			$jumlah_air,
			
			$luas_kavling,
			$tarif_ipl,
			$jumlah_ipl,
			
			@persen_ppn,
			
			'$ket_ivc', 
			
			'$sess_id_user'
		)";
		
		ex_false($conn->Execute($query), $query);
		
		$conn->committrans();
		
		$msg = 'Tagihan berhasil ditambahkan.';
	}
	catch(Exception $e)
	{
		$msg = $e->getmessage();
		$error = TRUE;
		$conn->rollbacktrans();
	}
}

close($conn);
$json = array('msg' => $msg, 'error'=> $error);
echo json_encode($json);
exit;

/*
$obj = $conn->Execute("
		SELECT 
			COUNT(ID_PEMBAYARAN) AS TOTAL, 
			(
				SELECT ISNULL(MAX(CAST(PERIODE_IPL_AKHIR AS INT)), 0)
				FROM KWT_PEMBAYARAN_AI
				WHERE 
					NO_PELANGGAN = '$no_pelanggan' AND 
					$where_trx_air_ipl AND 
					AKTIF_IPL = 1 
			) MAX_PERIODE_IPL_AKHIR
		FROM 
			KWT_PEMBAYARAN_AI p 
		WHERE 
			NO_PELANGGAN = '$no_pelanggan' AND 
			(CASE WHEN p.AKTIF_IPL = 1 THEN $periode_ipl_awal ELSE 1 END) > 
			(
				CASE WHEN p.AKTIF_IPL = 1
				THEN 
				(
					SELECT ISNULL(MAX(CAST(PERIODE_IPL_AKHIR AS INT)), 0)
					FROM KWT_PEMBAYARAN_AI
					WHERE 
						KODE_BLOK = p.KODE_BLOK AND 
						$where_trx_air_ipl AND 
						AKTIF_IPL = 1 
				)
				ELSE 0 END 
			)
		");
		ex_found($obj->fields['TOTAL'], "Periode akhir harus > " . $obj->fields['MAX_PERIODE_IPL_AKHIR']);
*/
?>