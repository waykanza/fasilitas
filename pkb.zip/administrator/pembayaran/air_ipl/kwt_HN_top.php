<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8">
<title>Kwitansi Hunian</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
@media print {
	.newpage {page-break-before:always;}
}

body {
	margin: 0 0 0 40px;
	color: #999;
}
table.kwt {
	font-size: 13px;
}
table.kwt td {
	border:none;
	vertical-align: top;
}
</style>
</head>

<body onload="window.print()">