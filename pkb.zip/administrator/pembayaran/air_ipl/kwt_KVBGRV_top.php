<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Cetak - Iuran Pemeliharaan Lingkungan</title>
<style type="text/css">
@media print {
	@page {
		size: 8.5in 4in portrait;
	}
	.newpage {page-break-before:always;}
}
table {
	border-collapse: collapse;
}
table tr td {
	font-family: "New Century Schoolbook", Times, serif;
	font-size: 12px;
	vertical-align: top;
}
.top-enabled {
	border-top:1px solid #000;
}
</style>
</head>

<body onload="window.print()">
<div id="wrap">
