<script type="text/javascript">
jQuery(function($) {
	$('#nav a').each(function() {
		var link = $(this).attr('href');
		link = (link == '') ? 'javascript:void(0)' : base_adm + '?cmd=' + link;
		$(this).attr('href', link);
	});
});
</script>
<div class="clear"></div>
<ul id="nav">
	<li><a href="">Master</a>
		<ul>
			<li><a href="<?php echo base64_encode('parameter'); ?>">Parameter</a></li>
			<li><a href="<?php echo base64_encode('sektor'); ?>">Sektor</a></li>
			<li><a href="<?php echo base64_encode('cluster'); ?>">Cluster</a></li>
			<li><a href="<?php echo base64_encode('bank'); ?>">Bank</a></li>
			
			<!-- AIR & IPL -->
			<li class="separator"> Air & IPL </li>
			<li><a href="">SK <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('sk_air'); ?>">Air</a></li>
					<li><a href="<?php echo base64_encode('sk_ipl'); ?>">IPL</a></li>
				</ul>
			</li>
			<li><a href="">Air <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('kategori_air'); ?>">Kategori</a></li>
					<li><a href="<?php echo base64_encode('tarif_air'); ?>">Tarif</a></li>
				</ul>
			</li>
			<li><a href="">IPL <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('kategori_ipl'); ?>">Kategori</a></li>
					<li><a href="<?php echo base64_encode('tarif_ipl'); ?>">Tarif</a></li>
				</ul>
			</li>
			<li><a href="<?php echo base64_encode('pelanggan'); ?>">Pelanggan</a></li>
			<?php if (in_array('M15', $sess_id_modul)) { 
				echo '<li><a href="' . base64_encode('pelanggan_fa') . '">Pelanggan (Full Access)</a></li>'; 
			} ?>
			<li>
				<a href="<?php echo base64_encode('pelanggan_baru'); ?>">Pelanggan Baru 
					(<?php echo $conn->Execute("SELECT COUNT(NO_PELANGGAN) AS TOTAL FROM KWT_PELANGGAN_IMP WHERE STATUS_PROSES = 0")->fields['TOTAL']; ?>)
				</a>
			</li>
			<li><a href="<?php echo base64_encode('diskon'); ?>">Diskon Khusus</a></li>
			<li><a href="<?php echo base64_encode('pompa'); ?>">Rumah Pompa</a></li>
		</ul>
	</li>
		
	<li><a href="">Proses Tagihan</a>
		<ul>
			<li><a href="<?php echo base64_encode('periode_bangun'); ?>">Periode Masa Membangun</a></li>
			<li><a href="<?php echo base64_encode('periode_renovasi'); ?>">Periode Renovasi</a></li>
			<li class="separator"></li>
			<li><a href="<?php echo base64_encode('copy_periode'); ?>">Copy Tagihan (Temp)</a></li>
			<li class="separator"></li>
			<li><a href="<?php echo base64_encode('edit_sm'); ?>">Edit Stand Meter</a></li>
			<li><a href="<?php echo base64_encode('export_sm'); ?>">Export Stand Meter</a></li>
			<li><a href="<?php echo base64_encode('import_sm'); ?>">Import Stand Meter</a></li>
			<li class="separator"></li>
			<li><a href="<?php echo base64_encode('proses_tagihan'); ?>">Proses Tagihan</a></li>
			<li><a href="<?php echo base64_encode('hitung_denda'); ?>">Hitung Denda</a></li>
		</ul>
	</li>
	
	<li><a href="">Bank</a>
		<ul>
			<li><a href="<?php echo base64_encode('export_bank'); ?>">Export</a></li>
			<li><a href="<?php echo base64_encode('import_bank'); ?>">Import</a></li>
		</ul>
	</li>
	
	<li><a href="">Pembayaran</a>
		<ul>
			<li><a href="<?php echo base64_encode('ai_pembayaran'); ?>">Air & IPL</a></li>
			<li><a href="<?php echo base64_encode('dp_pembayaran'); ?>">Deposit</a></li>
			<li><a href="<?php echo base64_encode('ll_pembayaran'); ?>">Biaya Lain-lain</a></li>
		</ul>
	</li>
	
	<li><a href="">Laporan <span></span></a>
		<ul>
			<li><a href="">Air & IPL <span></span></a>
				<ul>
					<li><a href="">Rencana <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ai_rencana_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ai_rencana_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Penerimaan <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ai_penerimaan_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ai_penerimaan_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Piutang <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ai_piutang_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ai_piutang_rekap'); ?>">Rekap</a></li>
							<li><a href="<?php echo base64_encode('ai_piutang_umur'); ?>">Umur Piutang</a></li>
						</ul>
					</li>
					<li><a href="<?php echo base64_encode('ai_pemutusan'); ?>">Pemutusan</a></li>
					<li><a href="<?php echo base64_encode('ai_pemakaian_air'); ?>">Pemakaian Air</a></li>
				</ul>
			</li>
			
			<li><a href="">Deposit <span></span></a>
				<ul>
					<li><a href="">Rencana <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('dp_rencana_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('dp_rencana_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Penerimaan <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('dp_penerimaan_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('dp_penerimaan_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Piutang <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('dp_piutang_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('dp_piutang_rekap'); ?>">Rekap</a></li>
							<li><a href="<?php echo base64_encode('dp_piutang_umur'); ?>">Umur Piutang</a></li>
						</ul>
					</li>
				</ul>
			</li>
			
			<li><a href="">Biaya Lain-lain <span></span></a>
				<ul>
					<li><a href="">Rencana <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ll_rencana_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ll_rencana_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Penerimaan <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ll_penerimaan_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ll_penerimaan_rekap'); ?>">Rekap</a></li>
						</ul>
					</li>
					<li><a href="">Piutang <span></span></a>
						<ul>
							<li><a href="<?php echo base64_encode('ll_piutang_rincian'); ?>">Rincian</a></li>
							<li><a href="<?php echo base64_encode('ll_piutang_rekap'); ?>">Rekap</a></li>
							<li><a href="<?php echo base64_encode('ll_piutang_umur'); ?>">Umur Piutang</a></li>
						</ul>
					</li>
				</ul>
			</li>
			
			<li><a href="">Pelanggan <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('pelanggan_rincian'); ?>">Rincian</a></li>
					<li><a href="<?php echo base64_encode('pelanggan_rekap'); ?>">Rekap</a></li>
					<li><a href="<?php echo base64_encode('pelanggan_daftar'); ?>">Daftar</a></li>
				</ul>
			</li>
			
			<li><a href="">BD <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('bd_rincian'); ?>">Rincian</a></li>
					<li><a href="<?php echo base64_encode('bd_rekap'); ?>">Rekap</a></li>
				</ul>
			</li>
			
			<li><a href="<?php echo base64_encode('daftar_faktur_pajak'); ?>">Daftar Faktur Pajak</a></li>
		</ul>
	</li>
	
	<li><a href="">Utilitas <span></span></a>
		<ul>
			<li><a href="">Invoice <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('ai_invoice'); ?>">Air & IPL</a></li>
					<li><a href="<?php echo base64_encode('dp_invoice'); ?>">Deposit</a></li>
					<li><a href="<?php echo base64_encode('ll_invoice'); ?>">Biaya Lain-lain</a></li>
				</ul>
			</li>
			<li><a href="<?php echo base64_encode('posting_pembayaran'); ?>">Posting Pembayaran</a></li>
			<li><a href="<?php echo base64_encode('proses_bd'); ?>">Proses BD</a></li>
			<li><a href="">Faktur Pajak <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('fp_penomoran'); ?>">Penomoran</a></li>
					<li><a href="<?php echo base64_encode('fp_posting'); ?>">Posting</a></li>
					<li><a href="<?php echo base64_encode('fp_cetak'); ?>">Cetak</a></li>
				</ul>
			</li>
			<li><a href="">User <span></span></a>
				<ul>
					<li><a href="<?php echo base64_encode('user_management'); ?>">Management</a></li>
					<li><a href="<?php echo base64_encode('user_log'); ?>">Log</a></li>
				</ul>
			</li>
		</ul>
	</li>
</ul>

<div id="profil">
	<a href="#"><?php echo $_SESSION['NAMA_USER']; ?></a> | <a href="<?php echo BASE_URL; ?>administrator/authentic.php?do=logout">Logout</a>
</div>

<div class="clear"></div>