<?php
require_once('../../../config/config.php');
die_login();
die_mod('T6');
$conn = conn();
die_conn($conn);

$msg = '';
$list_key_air = 'Daftar kategori / kode tarif Air yang belum terdaftar : ';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	try
	{
		$conn->begintrans();
		
		$periode_tag_now = date('Ym');
		
		$query = "
		DECLARE 
		@denda_rupiah NUMERIC(25),
		@denda_persen NUMERIC(5,2)
		
		SELECT 
			@denda_rupiah = DENDA_RUPIAH, 
			@denda_persen = DENDA_PERSEN
		FROM KWT_PARAMETER
		
		UPDATE b 
		SET 
			b.DENDA = 
			( 
				CASE WHEN (TIPE_DENDA = 1) THEN 
					
					CASE WHEN (ROUND ( ( (@denda_persen/100) * (b.JUMLAH_AIR + b.ABONEMEN) )/100 , 0) * 100) < @denda_rupiah THEN
						@denda_rupiah
					ELSE 
						(ROUND ( ( (@denda_persen/100) * (b.JUMLAH_AIR + b.ABONEMEN) )/100 , 0) * 100)
					END 
					
				ELSE
					@denda_rupiah
				END 
			), 
			
			b.USER_MODIFIED = '$sess_id_user', 
			b.MODIFIED_DATE = GETDATE() 
		FROM 
			KWT_PEMBAYARAN_AI b 
		WHERE 
			$where_trx_air_ipl AND 
			b.STATUS_BAYAR = 0 AND 
			b.AKTIF_AIR = 1 AND 
			CAST(b.PERIODE_TAG AS INT) < $periode_tag_now 
		";
		ex_false($conn->Execute($query), $query);
		
		# CEK KEY AIR 
		$obj = $conn->Execute("
		SELECT DISTINCT b.KEY_AIR 
		FROM
			KWT_PEMBAYARAN_AI b 
			LEFT JOIN KWT_TARIF_AIR a ON b.KEY_AIR = a.KEY_AIR 
		WHERE 
			$where_trx_air_ipl AND 
			b.STATUS_BAYAR = 0 AND 
			b.AKTIF_AIR = 1 AND 
			CAST(b.PERIODE_TAG AS INT) < $periode_tag_now AND 
			a.KEY_AIR IS NULL
		ORDER BY b.KEY_AIR");
		
		while( ! $obj->EOF) {
			
			$list_key_air .= "<br>" . $obj->fields['KEY_AIR'];
			$obj->movenext();
		}
		
		$conn->committrans();
		
		$msg = 'Proses hitung denda selesai.';
		#$msg = $query;
	}
	catch(Exception $e)
	{
		$msg = $e->getmessage();
		$conn->rollbacktrans();
	}

	close($conn);
	$json = array('msg' => $msg, 'list_key_air' => $list_key_air);
	echo json_encode($json);
	exit;
}
?>