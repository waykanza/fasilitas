<div class="title-page">PROSES HITUNG DENDA</div>

<form name="form" id="form" method="post">
<table class="t-control wauto-center">
<tr class="text-center">
	<td><br><input type="button" id="proses" value=" Proses "></td>
</tr>
</table>

<script type="text/javascript">
jQuery(function($) {
	
	$(document).on('click', '#proses', function(e) {
		e.preventDefault();
		
		$('#respon_air').html('');
				
		var url		= base_periode + 'hitung_denda/hitung_denda_proses.php',
			data	= $('#form').serialize();
			
		$.post(url, data, function(res) {
			$('#respon_air').html(res.list_key_air);
			alert(res.msg);
		}, 'json');
			
		return false;
	});
	
});
</script>
</form>

<br><br>
<div id="respon_air" style="background:#FFFFFF;border:2px solid #FF9900;padding:10px;"></div>

