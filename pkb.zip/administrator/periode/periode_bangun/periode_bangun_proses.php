<?php
require_once('../../../config/config.php');
die_login();
die_mod('T1');
$conn = conn();
die_conn($conn);

$msg = '';
$error = FALSE;

$act			= (isset($_REQUEST['act'])) ? clean($_REQUEST['act']) : '';
$idd			= (isset($_REQUEST['idd'])) ? base64_decode(clean($_REQUEST['idd'])) : '';
$kode_blok		= (isset($_REQUEST['kode_blok'])) ? clean($_REQUEST['kode_blok']) : '';

$periode_ipl_awal	= (isset($_REQUEST['periode_ipl_awal'])) ? to_periode($_REQUEST['periode_ipl_awal']) : '';
$jumlah_periode_ipl	= (isset($_REQUEST['jumlah_periode_ipl'])) ? to_number($_REQUEST['jumlah_periode_ipl']) : '';
$nilai_deposit		= (isset($_REQUEST['nilai_deposit'])) ? to_number($_REQUEST['nilai_deposit']) : '';
$nilai_lain_lain	= (isset($_REQUEST['nilai_lain_lain'])) ? to_number($_REQUEST['nilai_lain_lain']) : '';
$tipe_deposit		= (isset($_REQUEST['tipe_deposit'])) ? clean($_REQUEST['tipe_deposit']) : '';
$ket_deposit		= (isset($_REQUEST['ket_deposit'])) ? clean($_REQUEST['ket_deposit']) : '';
$ket_lain_lain		= (isset($_REQUEST['ket_lain_lain'])) ? clean($_REQUEST['ket_lain_lain']) : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if ($act == 'Simpan') # Proses Tambah
	{
		try
		{
			$conn->begintrans();
			
			ex_empty($periode_ipl_awal, 'Masukkan periode mulai.');
			ex_not_found($jumlah_periode_ipl, 'Jumlah periode harus > 0');
			ex_empty($tipe_deposit, 'Masukkan Tipe deposit.');
			
			$jumlah_periode_ipl--;
			$periode_ipl_akhir = periode_mod("+$jumlah_periode_ipl", $periode_ipl_awal);
			$jumlah_periode_ipl++;
			
			$query = "
			SELECT TOP 1
				p.STATUS_BLOK,
				d.STATUS_PROSES,
				d.PERIODE_IPL_AWAL,
				d.PERIODE_IPL_AKHIR
			FROM 
				KWT_PELANGGAN p
				LEFT JOIN KWT_PERIODE_DEPOSIT d ON 
					p.KODE_BLOK = d.KODE_BLOK 
					AND d.TRX = $trx_dbg 
			WHERE 
				p.KODE_BLOK = '$kode_blok'
			ORDER BY CAST(d.PERIODE_IPL_AKHIR AS INT) DESC
			";
			
			$obj = $conn->Execute($query);
			
			$prev_status_blok = $obj->fields['STATUS_BLOK'];
			$prev_status_proses = $obj->fields['STATUS_PROSES'];
			$prev_periode_ipl_awal = $obj->fields['PERIODE_IPL_AWAL'];
			$prev_periode_ipl_akhir = $obj->fields['PERIODE_IPL_AKHIR'];
			
			if ($prev_status_blok != $trx_bg)
			{
				throw new Exception('Status blok tidak sama dengan "Masa Membangun".');
			}
			if ($prev_periode_ipl_akhir != '')
			{
				if ($prev_status_proses != '1')
				{
					throw new Exception('Periode sebelumnya belum diproses.');
				}
				if ($periode_ipl_awal <= $prev_periode_ipl_akhir)
				{
					throw new Exception("Periode mulai harus lebih besar dari \"$prev_periode_ipl_akhir\".");
				}
			}
			
			$id_deposit = $trx_dbg . '#' . $periode_ipl_awal . '#' . $kode_blok;
			
			$query = "INSERT INTO KWT_PERIODE_DEPOSIT
			(
				ID_DEPOSIT,
				TRX,
				KODE_BLOK, 
				PERIODE_IPL_AWAL, 
				PERIODE_IPL_AKHIR, 
				JUMLAH_PERIODE_IPL, 
				NILAI_DEPOSIT, 
				NILAI_LAIN_LAIN, 
				TIPE_DEPOSIT, 
				KET_DEPOSIT, 
				KET_LAIN_LAIN, 
				
				USER_CREATED
			)
			VALUES
			(
				'$id_deposit', 
				$trx_dbg, 
				'$kode_blok', 
				'$periode_ipl_awal', 
				'$periode_ipl_akhir',
				$jumlah_periode_ipl,
				$nilai_deposit,
				$nilai_lain_lain,
				$tipe_deposit,
				'$ket_deposit', 
				'$ket_lain_lain', 
				
				'$sess_id_user'
			)";
			
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = "Periode masa membangun berhasil disimpan.";
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'Ubah') # Proses Ubah
	{
		try
		{
			$conn->begintrans();

			ex_empty($periode_ipl_awal, 'Masukkan periode mulai.');
			ex_not_found($jumlah_periode_ipl, 'Jumlah periode harus > 0');
			ex_empty($tipe_deposit, 'Masukkan Tipe deposit.');
			
			$jumlah_periode_ipl--;
			$periode_ipl_akhir = periode_mod("+$jumlah_periode_ipl", $periode_ipl_awal);
			$jumlah_periode_ipl++;
			
			$query = "
			DECLARE @idd VARCHAR(20) = '$idd'
			
			SELECT TOP 1
				p.STATUS_BLOK,
				d.STATUS_PROSES,
				d.PERIODE_IPL_AWAL,
				d.PERIODE_IPL_AKHIR,
				(SELECT STATUS_PROSES FROM KWT_PERIODE_DEPOSIT WHERE ID_DEPOSIT = @idd) AS THIS_STATUS_PROSES
			FROM 
				KWT_PELANGGAN p
				LEFT JOIN KWT_PERIODE_DEPOSIT d ON 
					p.KODE_BLOK = d.KODE_BLOK AND
					d.ID_DEPOSIT != @idd AND 
					CAST(d.PERIODE_IPL_AKHIR AS INT) < 
					(
						SELECT CAST(PERIODE_IPL_AWAL AS INT) 
						FROM KWT_PERIODE_DEPOSIT 
						WHERE ID_DEPOSIT = @idd
					)			
			WHERE 
				p.KODE_BLOK = '$kode_blok'
			ORDER BY CAST(d.PERIODE_IPL_AKHIR AS INT) DESC
			";
			
			$obj = $conn->Execute($query);
			
			$this_status_proses = $obj->fields['THIS_STATUS_PROSES'];
			if ($this_status_proses == '1')
			{
				throw new Exception('Periode telah diproses.');
			}
			
			$prev_status_blok	= $obj->fields['STATUS_BLOK'];
			$prev_status_proses	= $obj->fields['STATUS_PROSES'];
			$prev_periode_ipl_awal	= $obj->fields['PERIODE_IPL_AWAL'];
			$prev_periode_ipl_akhir	= $obj->fields['PERIODE_IPL_AKHIR'];
			
			if ($prev_status_blok != $trx_bg)
			{
				throw new Exception('Status blok tidak sama dengan "Masa Membangun".'.$query);
			}
			if ($prev_periode_ipl_akhir != '')
			{
				if ($prev_status_proses != '1')
				{
					throw new Exception('Periode sebelumnya belum diproses.');
				}
				if ($periode_ipl_awal <= $prev_periode_ipl_akhir)
				{
					throw new Exception("Periode mulai harus lebih besar dari \"$prev_periode_ipl_akhir\".");
				}
			}
			
			$id_deposit = $trx_dbg . '#' . $periode_ipl_awal . '#' . $kode_blok;
			
			$query = "
			UPDATE KWT_PERIODE_DEPOSIT 
			SET 
				ID_DEPOSIT = '$id_deposit', 
				KODE_BLOK = '$kode_blok', 
				PERIODE_IPL_AWAL = '$periode_ipl_awal', 
				PERIODE_IPL_AKHIR = '$periode_ipl_akhir', 
				JUMLAH_PERIODE_IPL = $jumlah_periode_ipl, 
				NILAI_DEPOSIT = $nilai_deposit, 
				NILAI_LAIN_LAIN = $nilai_lain_lain, 
				TIPE_DEPOSIT = $tipe_deposit, 
				KET_DEPOSIT = '$ket_deposit', 
				KET_LAIN_LAIN = '$ket_lain_lain', 
				
				USER_MODIFIED = '$sess_id_user', 
				MODIFIED_DATE = GETDATE() 
			WHERE
				ID_DEPOSIT = '$idd'
			";
			
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = 'Periode masa membangun berhasil diubah.';
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'delete') # Proses Delete
	{
		$act = array();
		
		try
		{
			$conn->begintrans();
			
			$query = "
			SELECT STATUS_PROSES 
			FROM KWT_PERIODE_DEPOSIT
			WHERE ID_DEPOSIT = '$idd'";
			
			$status_proses = $conn->Execute($query)->fields['STATUS_PROSES'];
			if ($status_proses == '1')
			{
				throw new Exception("Periode telah diproses.");
			}
			
			$conn->Execute("DELETE FROM KWT_PERIODE_DEPOSIT WHERE ID_DEPOSIT = '$idd'");
			
			$conn->committrans();
			
			$msg = 'Periode masa membangun berhasil dihapus.';
		}
		catch(Exception $e)
		{
			$msg = $e->getMessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}

	close($conn);
	$json = array('act' => $act, 'msg' => $msg, 'error'=> $error);
	echo json_encode($json);
	exit;
}

$nilai_deposit = $conn->Execute("
SELECT i.NILAI_DEPOSIT AS MASTER_NILAI_DEPOSIT
FROM KWT_PELANGGAN p LEFT JOIN KWT_TARIF_IPL i ON p.KEY_IPL = i.KEY_IPL
WHERE p.kode_blok = '$kode_blok'")->fields['MASTER_NILAI_DEPOSIT'];

if ($act == 'Ubah')
{
	$query = "
	SELECT
		dbo.PTPS(d.PERIODE_IPL_AWAL) AS PERIODE_IPL_AWAL,
		d.JUMLAH_PERIODE_IPL,
		d.NILAI_LAIN_LAIN,
		d.NILAI_DEPOSIT,
		d.TIPE_DEPOSIT,
		d.KET_LAIN_LAIN,
		d.KET_DEPOSIT
	FROM 
		KWT_PERIODE_DEPOSIT d
	WHERE
		d.ID_DEPOSIT = '$idd'";
	
	$obj = $conn->Execute($query);
	
	$periode_ipl_awal	= $obj->fields['PERIODE_IPL_AWAL'];
	$jumlah_periode_ipl	= $obj->fields['JUMLAH_PERIODE_IPL'];
	$nilai_deposit		= $obj->fields['NILAI_DEPOSIT'];
	$nilai_lain_lain	= $obj->fields['NILAI_LAIN_LAIN'];
	$tipe_deposit		= $obj->fields['TIPE_DEPOSIT'];
	$ket_deposit		= $obj->fields['KET_DEPOSIT'];
	$ket_lain_lain		= $obj->fields['KET_LAIN_LAIN'];
}

$idd		= base64_encode($idd);
$kode_blok	= $kode_blok;
?>