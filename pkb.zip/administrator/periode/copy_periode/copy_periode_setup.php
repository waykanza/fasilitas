<script type="text/javascript">
jQuery(function($) {

	$('#diskon_ipl').inputmask('numeric', { repeat: '10' });
	
	$('#close').click(function(e) {
		e.preventDefault();
		location.href = base_adm;
	});

	$('#proses').click(function(e) {
		e.preventDefault();
		var periode	= $('#periode_tag').val(),
			url		= base_periode + 'copy_periode/copy_periode_proses.php',
			data	= $('#form').serialize();
		
		if (periode == '')
		{
			alert('Masukkan periode tagihan.');
			$('#periode_tag').focus();
			return false;
		}
		
		$.post(url, data, function(result) {
			
			alert(result.msg);
		}, 'json');
	
		return false;
	});
});
</script>

<div class="title-page">COPY TAGIHAN</div>

<form name="form" method="post" id="form">
<table class="t-control wauto-center">
<!--tr>
	<td><input type="checkbox" name="single_blok" id="sglb" value="1"> <label for="sglb">BLOK/NO. </label></td>
	<td>
		<input type="text" name="kode_blok" id="kode_blok" value="" size="12">&nbsp;&nbsp;&nbsp;
		DISKON IPL &nbsp;<input type="text" name="diskon_ipl" id="diskon_ipl" value="" size="13">
	</td>
</tr>

<tr>
	<td colspan="2"><hr><br></td>
</tr-->

<tr>
	<td>PERIODE TAGIHAN</td>
	<td><input type="text" name="periode_tag" id="periode_tag" class="mm-yyyy" size="10" value=""></td>
</tr>
<tr>
	<td>PERIODE AWAL IPL &nbsp;</td>
	<td><input type="text" name="periode_ipl_awal" id="periode_ipl_awal" class="mm-yyyy" size="10" value=""> * KAVLING KOSONG</td>
</tr>
<tr>
	<td>JML. PERIODE IPL</td>
	<td><input type="text" name="jumlah_periode_ipl" id="jumlah_periode_ipl" class="text-center" size="2" value="1"> * KAVLING KOSONG</td>
</tr>
<tr>
	<td>TGL. JATUH TEMPO AIR & IPL</td>
	<td><input type="text" name="tgl_jatuh_tempo_air_ipl" id="tgl_jatuh_tempo_air_ipl" class="dd-mm-yyyy" size="12"></td>
</tr>
<tr>
	<td>TGL. JATUH TEMPO SAVE DEPOSIT</td>
	<td><input type="text" name="tgl_jatuh_tempo_deposit" id="tgl_jatuh_tempo_deposit" class="dd-mm-yyyy" size="12"></td>
</tr>
<tr>
	<td>TGL. JATUH TEMPO BIAYA LAIN-LAIN</td>
	<td><input type="text" name="tgl_jatuh_tempo_lain_lain" id="tgl_jatuh_tempo_lain_lain" class="dd-mm-yyyy" size="12"></td>
</tr>

<tr class="text-right">
	<td colspan="2">
		<hr>
		<input type="button" id="proses" value=" Proses ">&nbsp;&nbsp;
		<input type="button" id="close" value=" Tutup ">
	</td>
</tr>
</table>
</form>

<?php close($conn);?>
