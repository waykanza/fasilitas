<?php 
require_once('../../../config/config.php');
die_login();
die_mod('T3');
$conn = conn();
die_conn($conn);

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$single_blok		= (isset($_REQUEST['single_blok'])) ? clean($_REQUEST['single_blok']) : '';
	$kode_blok			= (isset($_REQUEST['kode_blok'])) ? clean($_REQUEST['kode_blok']) : '';
	$periode_tag		= (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']) : '';
	$periode_ipl_awal	= (isset($_REQUEST['periode_ipl_awal'])) ? to_periode($_REQUEST['periode_ipl_awal']) : '';
	$jumlah_periode_ipl	= (isset($_REQUEST['jumlah_periode_ipl'])) ? to_number($_REQUEST['jumlah_periode_ipl']) : '1';
	
	$tgl_jatuh_tempo_air_ipl = (isset($_REQUEST['tgl_jatuh_tempo_air_ipl'])) ? to_date($_REQUEST['tgl_jatuh_tempo_air_ipl']) : '';
	$tgl_jatuh_tempo_deposit = (isset($_REQUEST['tgl_jatuh_tempo_deposit'])) ? to_date($_REQUEST['tgl_jatuh_tempo_deposit']) : '';
	$tgl_jatuh_tempo_lain_lain = (isset($_REQUEST['tgl_jatuh_tempo_lain_lain'])) ? to_date($_REQUEST['tgl_jatuh_tempo_lain_lain']) : '';
	
	$where_single_blok = '';
	$diskon_ipl = 0;
	$tgl_diskon_ipl = 'NULL';
	$user_diskon_ipl = 'NULL';
	
	if ($single_blok == '1') {
		$diskon_ipl = (isset($_REQUEST['diskon_ipl'])) ? to_number($_REQUEST['diskon_ipl']) : '';
		$where_single_blok = " AND p.KODE_BLOK = '$kode_blok' ";
		
		if ($diskon_ipl > 0) {
			$tgl_diskon_ipl	= 'GETDATE()';
			$user_diskon_ipl = "'$sess_id_user'";
		}
	}
	
	try
	{
		$conn->begintrans();
		
		ex_empty($periode_tag, 'Masukkan periode tagihan.');
		
		if ($jumlah_periode_ipl == '' || $jumlah_periode_ipl == 0) {
			$jumlah_periode_ipl = 1;
		}
		if ($periode_ipl_awal == '') {
			$periode_ipl_awal = $periode_tag;
		}
		
		# PERIODE AIR
		$periode_air = periode_mod('-1', $periode_tag);
		$periode_air_prev = periode_mod('-1', $periode_air);
		
		# PERIODE IPL
		$periode_ipl_akhir = periode_mod('+' . ($jumlah_periode_ipl - 1), $periode_ipl_awal);
		
		# KOSONGKAN TABLE TEMPORARY
		$conn->Execute("TRUNCATE TABLE KWT_PEMBAYARAN_AI_TEMP");
		
		$ket_ivc_bg_rv_air_ipl = 'Tagihan Air Bersih dan IPL';
		$ket_ivc_bg_rv_air = 'Tagihan Air Bersih';
		$ket_ivc_kv_hn = 'Tagihan Air Bersih dan IPL';
		
		require_once('1_proses_bg_rv_AIR_IPL.php'); 
		require_once('2_proses_bg_rv_AIR.php'); 
		require_once('3_proses_kv.php'); 
		require_once('4_proses_hn.php'); 
		require_once('5_proses_dbg_drv.php'); # DEPOSIT (BG, RV)
		require_once('6_proses_lbg_lrv.php'); # LAIN-LAIN (BG, RV)
		
		$msg = 'Periode berhasil diproses!';
		
		$conn->committrans();
	}
	catch(Exception $e)
	{
		$msg = $e->getmessage();
		$conn->rollbacktrans();
	}
}

close($conn);
$result = array('msg' => $msg);
echo json_encode($result);					
?>	