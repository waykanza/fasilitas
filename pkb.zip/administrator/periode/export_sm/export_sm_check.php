<?php
require_once('../../../config/config.php');

$periode_tag = (isset($_REQUEST['periode_tag'])) ? to_periode($_REQUEST['periode_tag']):'';

$status = '';
$file_name = '';
$respon = '';

if ($periode_tag != '')
{
	$periode_air = periode_mod('-1', $periode_tag);
	$path = EXPORT_PATH . 'sm\\';
	
	$status = read_file($path . 'status.txt');
	
	if ($status == 'FINISH')
	{
		$respon = read_file($path . 'respon.txt');
		if ($respon == '')
		{
			$file_name = 'BIMASAKTI_EXPORT_'.$periode_air.'.txt';
		}
	}
}

echo json_encode(array('status' => $status, 'file_name' => $file_name, 'respon' => $respon));
exit;
?>