<?php
require_once('../../config/config.php');
die_login();
$conn = conn();
die_conn($conn);


$no_ktp = (isset($_REQUEST['no_ktp'])) ? clean($_REQUEST['no_ktp']) : '';
$act = (isset($_REQUEST['act'])) ? clean($_REQUEST['act']) : '';

if ($act == 'list')
{
	$echo = '';
	
	if ($no_ktp != '')
	{
		$obj = $conn->Execute("
		SELECT
			NO_KTP,
			LOWER(NAMA_PELANGGAN) AS NAMA_PELANGGAN,
			NPWP,
			ALAMAT,
			NO_TELEPON,
			NO_HP,
			KODE_BANK,
			NO_REKENING,
			
			SM_NAMA_PELANGGAN,
			SM_NO_KTP,
			SM_NPWP,
			SM_NO_HP,
			SM_NO_TELEPON,
			SM_ALAMAT
		FROM
			KWT_PELANGGAN_LOOKUP
		WHERE
			NO_KTP LIKE '$no_ktp%'
		ORDER BY NAMA_PELANGGAN ASC
		");
		while( ! $obj->EOF)
		{
			$id = $obj->fields['NO_KTP'];
			$echo .= "
			<div class='lp' onclick='javascript:pp(\"$id\")'>
				<div class='lp-nm'>".ucwords($obj->fields['NAMA_PELANGGAN'])." <span class='lp-nk'>$id</span></div>
			</div>";
			
			$obj->movenext();
		}
		
		close($conn);
		echo $echo;
	}
}
elseif ($act == 'sel')
{
	$echo = array(
		'no_ktp' => '',
		'nama_pelanggan' => '',
		'npwp' => '',
		'alamat' => '',
		'no_telepon' => '',
		'no_hp' => '',
		'kode_bank' => '',
		'no_rekening' => '',
		
		'sm_nama_pelanggan' => '',
		'sm_alamat' => '',
		'sm_no_telepon' => '',
		'sm_no_hp' => '',
	);
	
	if ($no_ktp != '')
	{
		$obj = $conn->Execute("
		SELECT
			NO_KTP,
			NAMA_PELANGGAN,
			NPWP,
			ALAMAT,
			NO_TELEPON,
			NO_HP,
			KODE_BANK,
			NO_REKENING,
			
			SM_NAMA_PELANGGAN,
			SM_NO_KTP,
			SM_NPWP,
			SM_NO_HP,
			SM_NO_TELEPON,
			SM_ALAMAT
		FROM
			KWT_PELANGGAN_LOOKUP
		WHERE
			NO_KTP = '$no_ktp'
		");
		
		$echo = array(
			'no_ktp' => $obj->fields['NO_KTP'],
			'nama_pelanggan' => $obj->fields['NAMA_PELANGGAN'],
			'npwp' => $obj->fields['NPWP'],
			'alamat' => $obj->fields['ALAMAT'],
			'no_telepon' => $obj->fields['NO_TELEPON'],
			'no_hp' => $obj->fields['NO_HP'],
			'kode_bank' => $obj->fields['KODE_BANK'],
			'no_rekening' => $obj->fields['NO_REKENING'],
			
			'sm_nama_pelanggan' => $obj->fields['SM_NAMA_PELANGGAN'],
			'sm_no_ktp' => $obj->fields['SM_NO_KTP'],
			'sm_npwp' => $obj->fields['SM_NPWP'],
			'sm_no_hp' => $obj->fields['SM_NO_HP'],
			'sm_no_telepon' => $obj->fields['SM_NO_TELEPON'],
			'sm_alamat' => $obj->fields['SM_ALAMAT']
		);
	}
	
	close($conn);
	echo json_encode($echo);
}
?>