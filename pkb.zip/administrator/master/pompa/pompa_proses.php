<?php
require_once('../../../config/config.php');
die_login();
die_mod('M6');
$conn = conn();
die_conn($conn);

$msg = '';
$error = FALSE;

$act	= (isset($_REQUEST['act'])) ? clean($_REQUEST['act']) : '';
$id		= (isset($_REQUEST['id'])) ? clean($_REQUEST['id']) : '';

$kode_zona	= (isset($_REQUEST['kode_zona'])) ? clean($_REQUEST['kode_zona']) : '';
$nama_zona	= (isset($_REQUEST['nama_zona'])) ? clean($_REQUEST['nama_zona']) : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if ($act == 'Simpan') # Proses Tambah
	{
		try
		{
			$conn->begintrans();
			
			ex_empty($kode_zona, 'Kode harus diisi.');
			ex_empty($nama_zona, 'Rumah pompa harus diisi.');
			
			$query = "SELECT COUNT(KODE_ZONA) AS TOTAL FROM KWT_ZMB WHERE KODE_ZONA = '$kode_zona'";
			ex_found($conn->Execute($query)->fields['TOTAL'], "Kode zona \"$kode_zona\" telah terdaftar.");
			
			$query = "INSERT INTO KWT_ZMB (KODE_ZONA, NAMA_ZONA, USER_CREATED)
			VALUES(
				'$kode_zona',
				'$nama_zona', 
				'$sess_id_user'
			)";
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = "Rumah pompa \"$nama_zona\" berhasil disimpan.";
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'Ubah') # Proses Ubah
	{
		try
		{
			$conn->begintrans();

			ex_empty($kode_zona, 'Kode harus diisi.');
			ex_empty($nama_zona, 'Rumah pompa harus diisi.');
			
			$query = "SELECT COUNT(KODE_ZONA) AS TOTAL FROM KWT_ZMB WHERE KODE_ZONA = '$kode_zona' AND KODE_ZONA != '$id'";
			ex_found($conn->Execute($query)->fields['TOTAL'], "Kode zona \"$kode_zona\" telah terdaftar.");
			
			$query = "
			UPDATE KWT_ZMB 
			SET 
				KODE_ZONA = '$kode_zona',
				NAMA_ZONA = '$nama_zona', 
					
				USER_MODIFIED = '$sess_id_user', 
				MODIFIED_DATE = GETDATE() 
			WHERE
				KODE_ZONA = '$id'
			";
			
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = 'Rumah pompa berhasil diubah.';
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'delete') # Proses Delete
	{
		$act = array();
		
		try
		{
			$conn->begintrans();
			
			$cb_data = $_REQUEST['cb_data'];
			ex_empty($cb_data, 'Pilih data yang akan dihapus.');
			
			foreach ($cb_data as $id_del)
			{
				$query = "DELETE FROM KWT_ZMB WHERE KODE_ZONA = '$id_del'";
				if ($conn->Execute($query)) {
					$act[] = $id_del;
				} else {
					$error = TRUE;
				}
			}
			
			$conn->committrans();
			
			$msg = ($error) ? 'Sebagian data gagal dihapus.' : 'Data rumah pompa berhasil dihapus.';
		}
		catch(Exception $e)
		{
			$msg = $e->getMessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}

	close($conn);
	$json = array('act' => $act, 'msg' => $msg, 'error'=> $error);
	echo json_encode($json);
	exit;
}

if ($act == 'Ubah')
{
	$query = "SELECT * FROM KWT_ZMB WHERE KODE_ZONA = '$id'";
	$obj = $conn->Execute($query);
	$kode_zona = $obj->fields['KODE_ZONA'];
	$nama_zona = $obj->fields['NAMA_ZONA'];
}
?>