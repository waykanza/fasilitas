<?php
require_once('../../../config/config.php');
die_login();
die_mod('M4');
$conn = conn();
die_conn($conn);

$msg = '';
$error = FALSE;

$act	= (isset($_REQUEST['act'])) ? clean($_REQUEST['act']) : '';
$id		= (isset($_REQUEST['id'])) ? clean($_REQUEST['id']) : '';

$kode_bank		= (isset($_REQUEST['kode_bank'])) ? clean($_REQUEST['kode_bank']) : '';
$nama_bank		= (isset($_REQUEST['nama_bank'])) ? clean($_REQUEST['nama_bank']) : '';
$cou_bd			= (isset($_REQUEST['cou_bd'])) ? to_number($_REQUEST['cou_bd']) : '';
$cou_bdt		= (isset($_REQUEST['cou_bdt'])) ? to_number($_REQUEST['cou_bdt']) : '';
$cabang_bank	= (isset($_REQUEST['cabang_bank'])) ? clean($_REQUEST['cabang_bank']) : '';
$alamat_bank	= (isset($_REQUEST['alamat_bank'])) ? clean($_REQUEST['alamat_bank']) : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
	if ($act == 'Simpan') # Proses Tambah
	{
		try
		{
			$conn->begintrans();
			
			ex_empty($kode_bank, 'Kode harus diisi.');
			ex_empty($nama_bank, 'Nama bank harus diisi.');
			
			$query = "SELECT COUNT(KODE_BANK) AS TOTAL FROM KWT_BANK WHERE KODE_BANK = '$kode_bank'";
			ex_found($conn->Execute($query)->fields['TOTAL'], "Kode \"$kode_bank\" bank telah terdaftar.");
				
			$query = "INSERT INTO KWT_BANK (KODE_BANK, NAMA_BANK, COU_BD, COU_BDT, CABANG_BANK, ALAMAT_BANK, USER_CREATED)
			VALUES(
				'$kode_bank', 
				'$nama_bank', 
				$cou_bd, 
				$cou_bdt, 
				'$cabang_bank',
				'$alamat_bank', 
				'$sess_id_user'
			)";
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = "Bank \"$nama_bank\" berhasil disimpan.";
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'Ubah') # Proses Ubah
	{
		try
		{
			$conn->begintrans();

			ex_empty($kode_bank, 'Kode harus diisi.');
			ex_empty($nama_bank, 'Nama bank harus diisi.');
			
			$query = "SELECT COUNT(KODE_BANK) AS TOTAL FROM KWT_BANK WHERE KODE_BANK = '$kode_bank' AND KODE_BANK != '$id'";
			ex_found($conn->Execute($query)->fields['TOTAL'], "Kode \"$kode_bank\" telah terdaftar.");
			
			$query = "
			UPDATE KWT_BANK 
			SET 
				KODE_BANK = '$kode_bank',
				NAMA_BANK = '$nama_bank',
				COU_BD = $cou_bd,
				COU_BDT = '$cou_bdt',
				CABANG_BANK = '$cabang_bank',
				ALAMAT_BANK = '$alamat_bank', 
					
				USER_MODIFIED = '$sess_id_user', 
				MODIFIED_DATE = GETDATE() 
			WHERE
				KODE_BANK = '$id'
			";
			
			ex_false($conn->Execute($query), $query);
			
			$conn->committrans();
			
			$msg = 'Bank berhasil diubah.';
		}
		catch(Exception $e)
		{
			$msg = $e->getmessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}
	elseif ($act == 'delete') # Proses Delete
	{
		$act = array();
		
		try
		{
			$conn->begintrans();
			
			$cb_data = $_REQUEST['cb_data'];
			ex_empty($cb_data, 'Pilih data yang akan dihapus.');
			
			foreach ($cb_data as $id_del)
			{
				$query = "DELETE FROM KWT_BANK WHERE KODE_BANK = '$id_del'";
				if ($conn->Execute($query)) {
					$act[] = $id_del;
				} else {
					$error = TRUE;
				}
			}
			
			$conn->committrans();
			
			$msg = ($error) ? 'Sebagian data gagal dihapus.' : 'Data bank berhasil dihapus.';
		}
		catch(Exception $e)
		{
			$msg = $e->getMessage();
			$error = TRUE;
			$conn->rollbacktrans();
		}
	}

	close($conn);
	$json = array('act' => $act, 'msg' => $msg, 'error'=> $error);
	echo json_encode($json);
	exit;
}

if ($act == 'Ubah')
{
	$query = "SELECT * FROM KWT_BANK WHERE KODE_BANK = '$id'";
	$obj = $conn->Execute($query);
	$kode_bank		= $obj->fields['KODE_BANK'];
	$nama_bank		= $obj->fields['NAMA_BANK'];
	$cou_bd			= $obj->fields['COU_BD'];
	$cou_bdt		= $obj->fields['COU_BDT'];
	$cabang_bank	= $obj->fields['CABANG_BANK'];
	$alamat_bank	= $obj->fields['ALAMAT_BANK'];
}
?>